import { useState } from "react";
import { Header } from "@/components/Header";
import { HeroSection } from "@/components/HeroSection";
import { TripList } from "@/components/TripList";
import { CreateTripForm } from "@/components/CreateTripForm";
import { TripDetail } from "@/components/TripDetail";
import { MapView } from "@/components/MapView";
import { TravelStatistics } from "@/components/TravelStatistics";
import { TravelPlanner } from "@/components/TravelPlanner";
import { PhotoGallery } from "@/components/PhotoGallery";
import { SocialSharing } from "@/components/SocialSharing";
import { useToast } from "@/hooks/use-toast";
import { useSupabaseTrips, Trip } from "@/hooks/useSupabaseTrips";

const Index = () => {
  const [currentView, setCurrentView] = useState("home");
  const [selectedTrip, setSelectedTrip] = useState<Trip | null>(null);
  const { trips, loading, deleteTrip } = useSupabaseTrips();
  const { toast } = useToast();

  const handleViewChange = (view: string) => {
    setCurrentView(view);
  };

  const handleCreateTrip = () => {
    setCurrentView("new-trip");
  };

  const handleViewTrip = (tripId: string) => {
    const trip = trips.find(t => t.id === tripId);
    if (trip) {
      setSelectedTrip(trip);
      setCurrentView("trip-detail");
    }
  };

  const handleTripCreated = (newTrip: Trip) => {
    setCurrentView("home");
  };

  const handleEditTrip = (trip: Trip) => {
    // TODO: Implement edit functionality
    toast({
      title: "Tính năng đang phát triển",
      description: "Chức năng chỉnh sửa chuyến đi sẽ có trong phiên bản tiếp theo!",
    });
  };

  const handleDeleteTrip = async (tripId: string) => {
    await deleteTrip(tripId);
  };

  const renderContent = () => {
    switch (currentView) {
      case "trips":
        return <TripList onViewTrip={handleViewTrip} trips={trips} />;
      case "statistics":
        return <TravelStatistics />;
      case "planner":
        return <TravelPlanner />;
      case "photos":
        return <PhotoGallery />;
      case "social":
        return <SocialSharing />;
      case "map":
        return <MapView />;
      case "new-trip":
        return (
          <CreateTripForm 
            onBack={() => setCurrentView("home")}
            onTripCreated={handleTripCreated}
          />
        );
      case "trip-detail":
        return selectedTrip ? (
          <TripDetail 
            trip={selectedTrip}
            onBack={() => setCurrentView("home")}
            onEditTrip={handleEditTrip}
            onDeleteTrip={handleDeleteTrip}
          />
        ) : null;
      default:
        return (
          <>
            <HeroSection onCreateTrip={handleCreateTrip} />
            <TripList onViewTrip={handleViewTrip} trips={trips} />
          </>
        );
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header currentView={currentView} onViewChange={handleViewChange} />
      {renderContent()}
    </div>
  );
};

export default Index;
