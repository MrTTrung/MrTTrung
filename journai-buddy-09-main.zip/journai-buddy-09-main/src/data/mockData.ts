export interface Trip {
  id: string;
  title: string;
  startDate: string;
  endDate: string;
  location: string;
  notes: string;
  rating: number;
  tags: string[];
  coverImage?: string;
}

export interface DiaryEntry {
  id: string;
  tripId: string;
  date: string;
  text: string;
  images: string[];
  mood: string;
  weather?: string;
  location?: string;
}

export interface Expense {
  id: string;
  tripId: string;
  date: string;
  category: string;
  amount: number;
  description: string;
  currency: string;
}

// Mock data
export const mockTrips: Trip[] = [
  {
    id: "1",
    title: "Hành trình Đà Lạt đáng nhớ",
    startDate: "2024-06-20",
    endDate: "2024-06-22",
    location: "Đà Lạt, Lâm Đồng",
    notes: "Không khí tuyệt vời, đồ ăn ngon! Thành phố ngàn hoa thực sự quyến rũ.",
    rating: 5,
    tags: ["ẩm thực", "núi", "lãng mạn", "nhiếp ảnh"],
    coverImage: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800"
  },
  {
    id: "2", 
    title: "Phú Quốc - Thiên đường biển đảo",
    startDate: "2024-08-10",
    endDate: "2024-08-15",
    location: "Phú Quốc, Kiên Giang",
    notes: "Biển xanh ngắt, cát trắng mịn. Sunset ở Dinh Cậu tuyệt đẹp!",
    rating: 4,
    tags: ["biển", "resort", "thư giãn", "sunset"],
    coverImage: "https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=800"
  },
  {
    id: "3",
    title: "Hà Nội - Nơi lưu giữ nét xưa",
    startDate: "2024-10-01",
    endDate: "2024-10-05",
    location: "Hà Nội",
    notes: "Phố cổ tấp nập, phở ngon, cà phê vỉa hè đậm đà. Mùa thu Hà Nội thật đẹp!",
    rating: 5,
    tags: ["văn hóa", "ẩm thực", "lịch sử", "phố cổ"],
    coverImage: "https://images.unsplash.com/photo-1583417319070-4a69db38a482?w=800"
  }
];

export const mockDiaryEntries: DiaryEntry[] = [
  {
    id: "1",
    tripId: "1",
    date: "2024-06-20",
    text: "Ngày đầu tiên ở Đà Lạt! Đi chợ Đà Lạt và ăn bánh căn ngon tuyệt. Không khí se lạnh, view núi đồi tuyệt đẹp. Tối nay sẽ dạo quanh hồ Xuân Hương.",
    images: ["https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400"],
    mood: "😍",
    weather: "Mát mẻ, 18°C",
    location: "Chợ Đà Lạt"
  },
  {
    id: "2",
    tripId: "1", 
    date: "2024-06-21",
    text: "Hôm nay đi cáp treo lên đỉnh Langbiang. View từ trên cao nhìn xuống thành phố Đà Lạt thật choáng ngợp! Chiều về uống cà phê ở một quán nhỏ có view đồi thông.",
    images: ["https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400"],
    mood: "🤩",
    weather: "Nắng nhẹ, 22°C", 
    location: "Langbiang"
  },
  {
    id: "3",
    tripId: "2",
    date: "2024-08-10",
    text: "Vừa đặt chân đến Phú Quốc! Biển xanh trong vắt, cát trắng mịn. Check in resort và ngay lập tức xuống biển tắm. Nước biển ấm áp, sóng nhẹ.",
    images: ["https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=400"],
    mood: "🏖️",
    weather: "Nắng đẹp, 32°C",
    location: "Bãi Sao"
  }
];

export const mockExpenses: Expense[] = [
  {
    id: "1",
    tripId: "1",
    date: "2024-06-20",
    category: "Ăn uống",
    amount: 120000,
    description: "Bữa trưa ngon tuyệt tại Góc Hà Thành - bánh căn + cà phê",
    currency: "VND"
  },
  {
    id: "2", 
    tripId: "1",
    date: "2024-06-20",
    category: "Di chuyển",
    amount: 500000,
    description: "Taxi từ sân bay về trung tâm + di chuyển trong ngày",
    currency: "VND"
  },
  {
    id: "3",
    tripId: "1", 
    date: "2024-06-21",
    category: "Vui chơi",
    amount: 200000,
    description: "Vé cáp treo lên đỉnh Langbiang (2 người)",
    currency: "VND"
  },
  {
    id: "4",
    tripId: "2",
    date: "2024-08-10", 
    category: "Lưu trú",
    amount: 1500000,
    description: "Resort 4 sao view biển (2 đêm)",
    currency: "VND"
  },
  {
    id: "5",
    tripId: "2",
    date: "2024-08-11",
    category: "Ăn uống", 
    amount: 800000,
    description: "Hải sản tươi sống tại chợ đêm Phú Quốc",
    currency: "VND"
  }
];

// Helper functions
export const getTripById = (id: string): Trip | undefined => {
  return mockTrips.find(trip => trip.id === id);
};

export const getEntriesByTripId = (tripId: string): DiaryEntry[] => {
  return mockDiaryEntries.filter(entry => entry.tripId === tripId);
};

export const getExpensesByTripId = (tripId: string): Expense[] => {
  return mockExpenses.filter(expense => expense.tripId === tripId);
};

export const getTotalExpensesByTrip = (tripId: string): number => {
  return mockExpenses
    .filter(expense => expense.tripId === tripId)
    .reduce((total, expense) => total + expense.amount, 0);
};

export const formatCurrency = (amount: number, currency: string = "VND"): string => {
  if (currency === "VND") {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND'
    }).format(amount);
  }
  return `${amount.toLocaleString()} ${currency}`;
};