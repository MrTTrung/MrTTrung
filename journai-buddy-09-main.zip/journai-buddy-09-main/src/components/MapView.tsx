import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, Navigation, Route, Calendar } from "lucide-react";
import { GoogleMap } from "@/components/GoogleMap";
import { useSupabaseTrips } from "@/hooks/useSupabaseTrips";

export const MapView = () => {
  const { trips, loading } = useSupabaseTrips();
  const sortedTrips = [...trips].sort((a, b) => new Date(a.start_date).getTime() - new Date(b.start_date).getTime());

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-foreground mb-2">Bản đồ hành trình</h2>
        <p className="text-muted-foreground">
          Theo dõi các địa điểm bạn đã khám phá
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Interactive Google Map */}
        <div className="lg:col-span-2">
          <GoogleMap 
            trips={trips.map(trip => ({
              id: trip.id,
              title: trip.title,
              location: trip.location,
              start_date: trip.start_date,
              end_date: trip.end_date
            }))}
            height="400px"
          />
        </div>

        {/* Trip Route */}
        <Card className="shadow-card-custom">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Route className="w-5 h-5" />
              Lộ trình chuyến đi
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {sortedTrips.map((trip, index) => (
                <div key={trip.id} className="flex items-start gap-3">
                  <div className="flex flex-col items-center">
                    <div className={`w-3 h-3 rounded-full ${
                      index === 0 ? 'bg-green-500' : 
                      index === sortedTrips.length - 1 ? 'bg-red-500' : 
                      'bg-primary'
                    }`} />
                    {index < sortedTrips.length - 1 && (
                      <div className="w-0.5 h-8 bg-border mt-1" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium text-sm truncate">{trip.title}</h4>
                    <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                      <MapPin className="w-3 h-3" />
                      {trip.location}
                    </p>
                    <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                      <Calendar className="w-3 h-3" />
                      {new Date(trip.start_date).toLocaleDateString('vi-VN')}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-6">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-green-500 rounded-full" />
              <span className="text-sm text-muted-foreground">Điểm xuất phát</span>
            </div>
            <p className="font-semibold mt-1">{sortedTrips[0]?.location || "Chưa có"}</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-red-500 rounded-full" />
              <span className="text-sm text-muted-foreground">Điểm cuối</span>
            </div>
            <p className="font-semibold mt-1">{sortedTrips[sortedTrips.length - 1]?.location || "Chưa có"}</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-primary" />
              <span className="text-sm text-muted-foreground">Tổng địa điểm</span>
            </div>
            <p className="font-semibold mt-1">{new Set(trips.map(t => t.location)).size}</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Route className="w-4 h-4 text-secondary" />
              <span className="text-sm text-muted-foreground">Quãng đường</span>
            </div>
            <p className="font-semibold mt-1">~2,500 km</p>
          </CardContent>
        </Card>
      </div>

      {/* Location List */}
      <Card className="mt-6 shadow-card-custom">
        <CardHeader>
          <CardTitle>Danh sách địa điểm đã đến</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array.from(new Set(trips.map(trip => trip.location))).map((location) => {
              const tripsAtLocation = trips.filter(trip => trip.location === location);
              const totalTrips = tripsAtLocation.length;
              
              return (
                <Card key={location} className="hover:shadow-travel transition-shadow duration-300">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="font-semibold">{location}</h3>
                      <Badge variant="secondary">{totalTrips} chuyến</Badge>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <span>Số chuyến:</span>
                      <span>{totalTrips}</span>
                    </div>
                    <div className="mt-2">
                      <p className="text-xs text-muted-foreground">
                        Lần gần nhất: {new Date(Math.max(...tripsAtLocation.map(t => new Date(t.end_date).getTime()))).toLocaleDateString('vi-VN')}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};