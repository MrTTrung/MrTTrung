import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Share2, 
  Heart, 
  MessageCircle, 
  Send, 
  Facebook, 
  Twitter, 
  Instagram,
  Copy,
  QrCode,
  Users,
  Globe,
  Lock,
  Camera,
  MapPin,
  Calendar,
  Star,
  ThumbsUp,
  BookOpen,
  Search
} from "lucide-react";
import { mockTrips, formatCurrency, getTotalExpensesByTrip } from "@/data/mockData";
import { useToast } from "@/hooks/use-toast";

interface SocialPost {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  tripId: string;
  content: string;
  images: string[];
  likes: number;
  comments: number;
  shares: number;
  timestamp: string;
  location: string;
  isLiked: boolean;
}

interface Comment {
  id: string;
  postId: string;
  userId: string;
  userName: string;
  userAvatar: string;
  content: string;
  timestamp: string;
  likes: number;
}

export const SocialSharing = () => {
  const { toast } = useToast();
  const [selectedTrip, setSelectedTrip] = useState<string>('');
  const [postContent, setPostContent] = useState('');
  const [privacy, setPrivacy] = useState<'public' | 'friends' | 'private'>('public');

  // Mock social posts
  const socialPosts: SocialPost[] = [
    {
      id: '1',
      userId: 'user1',
      userName: 'Minh Châu',
      userAvatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=100',
      tripId: '1',
      content: 'Đà Lạt thật sự là thiên đường! Không khí mát mẻ, phong cảnh tuyệt đẹp. Đặc biệt là bánh căn ở chợ Đà Lạt ngon không thể tả! 😍 #DaLat #Travel #Vietnam',
      images: ['https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=600'],
      likes: 45,
      comments: 12,
      shares: 8,
      timestamp: '2024-06-22T10:30:00Z',
      location: 'Đà Lạt, Lâm Đồng',
      isLiked: true
    },
    {
      id: '2',
      userId: 'user2',
      userName: 'Thanh Hương',
      userAvatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100',
      tripId: '2',
      content: 'Sunset ở Dinh Cậu Phú Quốc tuyệt vời quá! Cảm giác như thời gian dừng lại. Resort view biển cũng xịn sò lắm 🌅🏖️',
      images: ['https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=600'],
      likes: 67,
      comments: 18,
      shares: 15,
      timestamp: '2024-08-15T18:45:00Z',
      location: 'Phú Quốc, Kiên Giang',
      isLiked: false
    }
  ];

  const comments: Comment[] = [
    {
      id: '1',
      postId: '1',
      userId: 'user3',
      userName: 'Long Vũ',
      userAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100',
      content: 'Mình cũng đi Đà Lạt tuần trước! Bánh căn ở chợ thật sự ngon 👍',
      timestamp: '2024-06-22T11:00:00Z',
      likes: 5
    },
    {
      id: '2',
      postId: '1',
      userId: 'user4',
      userName: 'Mai Linh',
      userAvatar: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?w=100',
      content: 'Chia sẻ địa điểm ăn bánh căn ngon với mình được không? 😊',
      timestamp: '2024-06-22T12:15:00Z',
      likes: 2
    }
  ];

  const createPost = () => {
    if (!selectedTrip || !postContent) {
      toast({
        title: "Vui lòng điền đầy đủ thông tin",
        description: "Chọn chuyến đi và viết nội dung bài đăng",
        variant: "destructive"
      });
      return;
    }

    toast({
      title: "Đã chia sẻ thành công!",
      description: "Bài đăng của bạn đã được chia sẻ với cộng đồng",
    });

    setPostContent('');
    setSelectedTrip('');
  };

  const shareToSocial = (platform: string, trip: any) => {
    const url = `https://travel-diary.app/trip/${trip.id}`;
    const text = `Vừa có chuyến đi tuyệt vời đến ${trip.location}! ${trip.notes}`;
    
    let shareUrl = '';
    switch (platform) {
      case 'facebook':
        shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`;
        break;
      case 'twitter':
        shareUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`;
        break;
      case 'instagram':
        toast({
          title: "Chức năng đang phát triển",
          description: "Tính năng chia sẻ Instagram sẽ có trong phiên bản tiếp theo",
        });
        return;
    }
    
    if (shareUrl) {
      window.open(shareUrl, '_blank', 'width=600,height=400');
    }
  };

  const copyTripLink = (tripId: string) => {
    const url = `https://travel-diary.app/trip/${tripId}`;
    navigator.clipboard.writeText(url).then(() => {
      toast({
        title: "Đã sao chép liên kết",
        description: "Link đã được sao chép vào clipboard",
      });
    });
  };

  const toggleLike = (postId: string) => {
    toast({
      title: "Đã thích bài đăng",
      description: "Cảm ơn bạn đã tương tác!",
    });
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-foreground mb-2">Chia sẻ & Cộng đồng</h2>
        <p className="text-muted-foreground">
          Chia sẻ những trải nghiệm du lịch với bạn bè và cộng đồng
        </p>
      </div>

      <Tabs defaultValue="share" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="share">Chia sẻ</TabsTrigger>
          <TabsTrigger value="community">Cộng đồng</TabsTrigger>
          <TabsTrigger value="discover">Khám phá</TabsTrigger>
        </TabsList>

        <TabsContent value="share" className="space-y-6">
          {/* Create New Post */}
          <Card className="shadow-card-custom">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Send className="w-5 h-5" />
                Tạo bài đăng mới
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-3">
                <Avatar>
                  <AvatarImage src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100" />
                  <AvatarFallback>BN</AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium">Bạn</p>
                  <div className="flex items-center gap-2">
                    {privacy === 'public' && <Globe className="w-3 h-3 text-muted-foreground" />}
                    {privacy === 'friends' && <Users className="w-3 h-3 text-muted-foreground" />}
                    {privacy === 'private' && <Lock className="w-3 h-3 text-muted-foreground" />}
                    <select
                      className="text-xs text-muted-foreground border-none bg-transparent"
                      value={privacy}
                      onChange={(e) => setPrivacy(e.target.value as any)}
                    >
                      <option value="public">Công khai</option>
                      <option value="friends">Bạn bè</option>
                      <option value="private">Riêng tư</option>
                    </select>
                  </div>
                </div>
              </div>

              <select
                className="w-full px-3 py-2 border border-input rounded-md"
                value={selectedTrip}
                onChange={(e) => setSelectedTrip(e.target.value)}
              >
                <option value="">Chọn chuyến đi để chia sẻ</option>
                {mockTrips.map(trip => (
                  <option key={trip.id} value={trip.id}>{trip.title}</option>
                ))}
              </select>

              <Textarea
                placeholder="Chia sẻ trải nghiệm du lịch của bạn..."
                value={postContent}
                onChange={(e) => setPostContent(e.target.value)}
                rows={4}
              />

              <div className="flex items-center justify-between">
                <div className="flex gap-2">
                  <Button variant="outline" size="sm">
                    <Camera className="w-4 h-4 mr-2" />
                    Thêm ảnh
                  </Button>
                  <Button variant="outline" size="sm">
                    <MapPin className="w-4 h-4 mr-2" />
                    Thêm địa điểm
                  </Button>
                </div>
                <Button onClick={createPost}>
                  <Send className="w-4 h-4 mr-2" />
                  Chia sẻ
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Quick Share Trip Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {mockTrips.map(trip => (
              <Card key={trip.id} className="shadow-card-custom">
                <CardContent className="p-4">
                  <div className="relative mb-4">
                    <img
                      src={trip.coverImage}
                      alt={trip.title}
                      className="w-full h-32 object-cover rounded-lg"
                    />
                    <div className="absolute top-2 right-2">
                      <div className="flex items-center gap-1 bg-black/50 rounded-full px-2 py-1">
                        <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" />
                        <span className="text-white text-xs">{trip.rating}</span>
                      </div>
                    </div>
                  </div>

                  <h3 className="font-semibold mb-2">{trip.title}</h3>
                  <div className="space-y-1 text-sm text-muted-foreground mb-4">
                    <p className="flex items-center gap-1">
                      <MapPin className="w-3 h-3" />
                      {trip.location}
                    </p>
                    <p className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {new Date(trip.startDate).toLocaleDateString('vi-VN')} - {new Date(trip.endDate).toLocaleDateString('vi-VN')}
                    </p>
                  </div>

                  <div className="flex gap-2 mb-4">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => shareToSocial('facebook', trip)}
                      className="flex-1"
                    >
                      <Facebook className="w-4 h-4 mr-1" />
                      FB
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => shareToSocial('twitter', trip)}
                      className="flex-1"
                    >
                      <Twitter className="w-4 h-4 mr-1" />
                      Twitter
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => shareToSocial('instagram', trip)}
                      className="flex-1"
                    >
                      <Instagram className="w-4 h-4 mr-1" />
                      IG
                    </Button>
                  </div>

                  <div className="flex gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => copyTripLink(trip.id)}
                      className="flex-1"
                    >
                      <Copy className="w-4 h-4 mr-2" />
                      Sao chép link
                    </Button>
                    <Button variant="ghost" size="sm">
                      <QrCode className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="community" className="space-y-6">
          {/* Community Posts */}
          <div className="space-y-6">
            {socialPosts.map(post => (
              <Card key={post.id} className="shadow-card-custom">
                <CardContent className="p-6">
                  {/* Post Header */}
                  <div className="flex items-center gap-3 mb-4">
                    <Avatar>
                      <AvatarImage src={post.userAvatar} />
                      <AvatarFallback>{post.userName.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <p className="font-medium">{post.userName}</p>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <MapPin className="w-3 h-3" />
                        <span>{post.location}</span>
                        <span>•</span>
                        <span>{new Date(post.timestamp).toLocaleDateString('vi-VN')}</span>
                      </div>
                    </div>
                  </div>

                  {/* Post Content */}
                  <p className="mb-4">{post.content}</p>

                  {/* Post Images */}
                  {post.images.length > 0 && (
                    <div className="mb-4">
                      <img
                        src={post.images[0]}
                        alt="Post image"
                        className="w-full max-h-96 object-cover rounded-lg"
                      />
                    </div>
                  )}

                  {/* Post Stats */}
                  <div className="flex items-center justify-between text-sm text-muted-foreground mb-4">
                    <span>{post.likes} lượt thích</span>
                    <div className="flex gap-4">
                      <span>{post.comments} bình luận</span>
                      <span>{post.shares} chia sẻ</span>
                    </div>
                  </div>

                  {/* Post Actions */}
                  <div className="flex items-center justify-between border-t pt-4">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => toggleLike(post.id)}
                      className={`flex-1 ${post.isLiked ? 'text-red-500' : ''}`}
                    >
                      <Heart className={`w-4 h-4 mr-2 ${post.isLiked ? 'fill-red-500' : ''}`} />
                      Thích
                    </Button>
                    <Button variant="ghost" size="sm" className="flex-1">
                      <MessageCircle className="w-4 h-4 mr-2" />
                      Bình luận
                    </Button>
                    <Button variant="ghost" size="sm" className="flex-1">
                      <Share2 className="w-4 h-4 mr-2" />
                      Chia sẻ
                    </Button>
                  </div>

                  {/* Comments Section */}
                  <div className="mt-4 space-y-3">
                    {comments.filter(c => c.postId === post.id).map(comment => (
                      <div key={comment.id} className="flex gap-3">
                        <Avatar className="w-8 h-8">
                          <AvatarImage src={comment.userAvatar} />
                          <AvatarFallback>{comment.userName.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1 bg-muted rounded-lg p-3">
                          <p className="font-medium text-sm">{comment.userName}</p>
                          <p className="text-sm">{comment.content}</p>
                          <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
                            <span>{new Date(comment.timestamp).toLocaleDateString('vi-VN')}</span>
                            <button className="hover:text-foreground">Thích ({comment.likes})</button>
                            <button className="hover:text-foreground">Trả lời</button>
                          </div>
                        </div>
                      </div>
                    ))}
                    
                    {/* Add Comment */}
                    <div className="flex gap-3 mt-4">
                      <Avatar className="w-8 h-8">
                        <AvatarImage src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100" />
                        <AvatarFallback>BN</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <Input
                          placeholder="Viết bình luận..."
                          className="rounded-full"
                        />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="discover">
          <Card className="shadow-card-custom">
            <CardContent className="p-16 text-center">
              <BookOpen className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
              <h3 className="text-xl font-semibold mb-2">Khám phá cộng đồng</h3>
              <p className="text-muted-foreground mb-4">
                Tìm hiểu những địa điểm mới từ cộng đồng du lịch
              </p>
              <Button>
                <Search className="w-4 h-4 mr-2" />
                Tìm kiếm địa điểm
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};