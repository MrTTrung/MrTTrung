import { useEffect, useRef, useState } from 'react';
import { Loader } from '@googlemaps/js-api-loader';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { MapPin, Search } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Label } from '@/components/ui/label';

// Component for API key input
const GoogleMapsAPIKeyInput = () => {
  const [apiKey, setApiKey] = useState(localStorage.getItem('google_maps_api_key') || '');
  const { toast } = useToast();

  const handleSaveApiKey = () => {
    if (apiKey.trim()) {
      localStorage.setItem('google_maps_api_key', apiKey.trim());
      toast({
        title: 'Thành công',
        description: 'Đã lưu Google Maps API key. Trang sẽ tải lại.',
      });
      setTimeout(() => window.location.reload(), 1000);
    } else {
      toast({
        title: 'Lỗi',
        description: 'Vui lòng nhập API key hợp lệ.',
        variant: 'destructive'
      });
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MapPin className="w-5 h-5" />
          Cấu hình Google Maps
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="text-center p-6 bg-muted rounded-lg">
            <MapPin className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-semibold mb-2">Cần Google Maps API Key</h3>
            <p className="text-muted-foreground mb-4">
              Để sử dụng Google Maps, bạn cần cấu hình API key
            </p>
            <div className="text-sm text-muted-foreground text-left max-w-md mx-auto">
              <p>1. Truy cập <a href="https://console.cloud.google.com/apis/credentials" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Google Cloud Console</a></p>
              <p>2. Tạo project mới hoặc chọn project có sẵn</p>
              <p>3. Bật Maps JavaScript API</p>
              <p>4. Tạo API key và nhập vào ô bên dưới</p>
            </div>
          </div>
          
          <div className="space-y-3">
            <Label htmlFor="api-key">Google Maps API Key</Label>
            <Input
              id="api-key"
              type="password"
              placeholder="Nhập Google Maps API Key..."
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
            />
            <Button onClick={handleSaveApiKey} className="w-full">
              Lưu API Key
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

// For development, you can add your Google Maps API key here
// For production, this should be stored in environment variables
const GOOGLE_MAPS_API_KEY = localStorage.getItem('google_maps_api_key') || "YOUR_GOOGLE_MAPS_API_KEY";

interface GoogleMapProps {
  trips?: Array<{
    id: string;
    title: string;
    location: string;
    start_date: string;
    end_date: string;
  }>;
  height?: string;
  onLocationSelect?: (location: { lat: number; lng: number; address: string }) => void;
  center?: { lat: number; lng: number };
}

export const GoogleMap = ({ 
  trips = [], 
  height = "400px", 
  onLocationSelect,
  center = { lat: 16.047079, lng: 108.206230 } // Default to Vietnam center
}: GoogleMapProps) => {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<google.maps.Map | null>(null);
  const markersRef = useRef<google.maps.Marker[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoaded, setIsLoaded] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const initMap = async () => {
      try {
        const loader = new Loader({
          apiKey: GOOGLE_MAPS_API_KEY,
          version: 'weekly',
          libraries: ['places', 'geometry']
        });

        await loader.load();
        
        if (mapRef.current) {
          const map = new google.maps.Map(mapRef.current, {
            center,
            zoom: 6,
            styles: [
              {
                featureType: 'poi',
                elementType: 'labels',
                stylers: [{ visibility: 'off' }]
              }
            ]
          });

          mapInstanceRef.current = map;
          setIsLoaded(true);

          // Add click listener for location selection
          if (onLocationSelect) {
            map.addListener('click', async (e: google.maps.MapMouseEvent) => {
              if (e.latLng) {
                const geocoder = new google.maps.Geocoder();
                try {
                  const response = await geocoder.geocode({ location: e.latLng });
                  if (response.results[0]) {
                    onLocationSelect({
                      lat: e.latLng.lat(),
                      lng: e.latLng.lng(),
                      address: response.results[0].formatted_address
                    });
                  }
                } catch (error) {
                  console.error('Geocoding error:', error);
                }
              }
            });
          }
        }
      } catch (error) {
        console.error('Error loading Google Maps:', error);
        toast({
          title: 'Lỗi bản đồ',
          description: 'Không thể tải Google Maps. Vui lòng kiểm tra API key.',
          variant: 'destructive'
        });
      }
    };

    initMap();
  }, [center, onLocationSelect, toast]);

  useEffect(() => {
    if (isLoaded && mapInstanceRef.current && trips.length > 0) {
      // Clear existing markers
      markersRef.current.forEach(marker => marker.setMap(null));
      markersRef.current = [];

      // Add markers for trips
      const geocoder = new google.maps.Geocoder();
      const bounds = new google.maps.LatLngBounds();

      trips.forEach(async (trip) => {
        try {
          const response = await geocoder.geocode({ address: trip.location });
          if (response.results[0]) {
            const position = response.results[0].geometry.location;
            
            const marker = new google.maps.Marker({
              position,
              map: mapInstanceRef.current,
              title: trip.title,
              icon: {
                path: google.maps.SymbolPath.CIRCLE,
                scale: 8,
                fillColor: '#3B82F6',
                fillOpacity: 1,
                strokeColor: '#FFFFFF',
                strokeWeight: 2
              }
            });

            const infoWindow = new google.maps.InfoWindow({
              content: `
                <div style="padding: 8px;">
                  <h3 style="margin: 0 0 4px 0; font-weight: bold;">${trip.title}</h3>
                  <p style="margin: 0; color: #666;">${trip.location}</p>
                  <p style="margin: 4px 0 0 0; font-size: 12px; color: #888;">
                    ${new Date(trip.start_date).toLocaleDateString('vi-VN')} - 
                    ${new Date(trip.end_date).toLocaleDateString('vi-VN')}
                  </p>
                </div>
              `
            });

            marker.addListener('click', () => {
              infoWindow.open(mapInstanceRef.current, marker);
            });

            markersRef.current.push(marker);
            bounds.extend(position);
          }
        } catch (error) {
          console.error('Error geocoding location:', error);
        }
      });

      // Fit map to show all markers
      if (trips.length > 1) {
        mapInstanceRef.current.fitBounds(bounds);
      }
    }
  }, [isLoaded, trips]);

  const handleSearch = async () => {
    if (!searchQuery.trim() || !isLoaded || !mapInstanceRef.current) return;

    const geocoder = new google.maps.Geocoder();
    try {
      const response = await geocoder.geocode({ address: searchQuery });
      if (response.results[0]) {
        const location = response.results[0].geometry.location;
        mapInstanceRef.current.setCenter(location);
        mapInstanceRef.current.setZoom(14);
        
        if (onLocationSelect) {
          onLocationSelect({
            lat: location.lat(),
            lng: location.lng(),
            address: response.results[0].formatted_address
          });
        }
      } else {
        toast({
          title: 'Không tìm thấy',
          description: 'Không thể tìm thấy địa điểm này.',
          variant: 'destructive'
        });
      }
    } catch (error) {
      console.error('Search error:', error);
      toast({
        title: 'Lỗi tìm kiếm',
        description: 'Có lỗi xảy ra khi tìm kiếm địa điểm.',
        variant: 'destructive'
      });
    }
  };

  if (GOOGLE_MAPS_API_KEY === "YOUR_GOOGLE_MAPS_API_KEY") {
    return <GoogleMapsAPIKeyInput />;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MapPin className="w-5 h-5" />
          Bản đồ Google Maps
        </CardTitle>
        <div className="flex gap-2">
          <Input
            placeholder="Tìm kiếm địa điểm..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
            className="flex-1"
          />
          <Button onClick={handleSearch} size="icon" variant="outline">
            <Search className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div 
          ref={mapRef} 
          style={{ height, width: '100%' }}
          className="rounded-lg overflow-hidden border"
        />
        {!isLoaded && (
          <div className="absolute inset-0 flex items-center justify-center bg-muted rounded-lg">
            <div className="text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-2"></div>
              <p className="text-sm text-muted-foreground">Đang tải bản đồ...</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};