import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { 
  Calendar, 
  MapPin, 
  Star, 
  DollarSign, 
  Camera, 
  Clock, 
  Plane,
  Target,
  TrendingUp
} from "lucide-react";
import { Trip, mockTrips, getTotalExpensesByTrip, formatCurrency } from "@/data/mockData";

export const TravelStatistics = () => {
  const totalTrips = mockTrips.length;
  const totalLocations = new Set(mockTrips.map(t => t.location)).size;
  const totalExpenses = mockTrips.reduce((sum, trip) => sum + getTotalExpensesByTrip(trip.id), 0);
  const averageRating = mockTrips.reduce((sum, trip) => sum + trip.rating, 0) / totalTrips;
  
  // Calculate travel days
  const totalDays = mockTrips.reduce((sum, trip) => {
    const start = new Date(trip.startDate);
    const end = new Date(trip.endDate);
    return sum + Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)) + 1;
  }, 0);

  // Travel goals (example data)
  const yearlyGoal = 12;
  const budgetGoal = 50000000; // 50M VND
  const locationsGoal = 20;

  const currentYear = new Date().getFullYear();
  const currentYearTrips = mockTrips.filter(trip => 
    new Date(trip.startDate).getFullYear() === currentYear
  ).length;

  const stats = [
    {
      title: "Tổng chuyến đi",
      value: totalTrips,
      icon: Plane,
      color: "text-primary",
      progress: (currentYearTrips / yearlyGoal) * 100,
      subtitle: `${currentYearTrips}/${yearlyGoal} chuyến năm ${currentYear}`
    },
    {
      title: "Địa điểm đã đến",
      value: totalLocations,
      icon: MapPin,
      color: "text-accent",
      progress: (totalLocations / locationsGoal) * 100,
      subtitle: `${totalLocations}/${locationsGoal} địa điểm`
    },
    {
      title: "Tổng chi phí",
      value: formatCurrency(totalExpenses),
      icon: DollarSign,
      color: "text-secondary",
      progress: (totalExpenses / budgetGoal) * 100,
      subtitle: `${Math.round((totalExpenses / budgetGoal) * 100)}% mục tiêu năm`
    },
    {
      title: "Đánh giá trung bình",
      value: averageRating.toFixed(1),
      icon: Star,
      color: "text-secondary",
      progress: (averageRating / 5) * 100,
      subtitle: `${averageRating.toFixed(1)}/5 sao`
    }
  ];

  const achievements = [
    { name: "Du lịch gia đình", icon: "👨‍👩‍👧‍👦", unlocked: totalTrips >= 3 },
    { name: "Khám phá miền Bắc", icon: "🏔️", unlocked: mockTrips.some(t => t.location.includes("Hà Nội")) },
    { name: "Khám phá miền Nam", icon: "🌴", unlocked: mockTrips.some(t => t.location.includes("Phú Quốc")) },
    { name: "Chụp ảnh chuyên nghiệp", icon: "📸", unlocked: totalTrips >= 5 },
    { name: "Ngân sách thông minh", icon: "💰", unlocked: totalExpenses < budgetGoal },
    { name: "Reviewer chuyên nghiệp", icon: "⭐", unlocked: averageRating >= 4.5 }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-foreground mb-2">Thống kê du lịch</h2>
        <p className="text-muted-foreground">
          Tổng quan về hành trình khám phá của bạn
        </p>
      </div>

      {/* Main Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index} className="relative overflow-hidden shadow-card-custom">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <Icon className={`w-8 h-8 ${stat.color}`} />
                  <TrendingUp className="w-4 h-4 text-muted-foreground" />
                </div>
                <div className="space-y-2">
                  <h3 className="text-2xl font-bold">{stat.value}</h3>
                  <p className="text-sm text-muted-foreground">{stat.title}</p>
                  <div className="space-y-2">
                    <Progress value={stat.progress} className="h-2" />
                    <p className="text-xs text-muted-foreground">{stat.subtitle}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Travel Timeline */}
        <Card className="shadow-card-custom">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              Thời gian du lịch
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Tổng số ngày đi du lịch</span>
                <span className="font-semibold">{totalDays} ngày</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Chuyến đi dài nhất</span>
                <span className="font-semibold">6 ngày</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Chuyến đi ngắn nhất</span>
                <span className="font-semibold">3 ngày</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Thời gian trung bình</span>
                <span className="font-semibold">{Math.round(totalDays / totalTrips)} ngày</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Monthly Activity */}
        <Card className="shadow-card-custom">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="w-5 h-5" />
              Hoạt động theo tháng
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-2">
              {Array.from({length: 12}, (_, i) => {
                const month = i + 1;
                const tripsInMonth = mockTrips.filter(trip => 
                  new Date(trip.startDate).getMonth() + 1 === month
                ).length;
                return (
                  <div key={month} className="text-center p-2 rounded-lg border">
                    <div className="text-xs text-muted-foreground">T{month}</div>
                    <div className="font-semibold">{tripsInMonth}</div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Achievements */}
      <Card className="shadow-card-custom">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="w-5 h-5" />
            Thành tích đạt được
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {achievements.map((achievement, index) => (
              <div
                key={index}
                className={`text-center p-4 rounded-lg border transition-all duration-300 ${
                  achievement.unlocked
                    ? 'bg-gradient-nature border-accent shadow-travel'
                    : 'bg-muted border-border opacity-50'
                }`}
              >
                <div className="text-2xl mb-2">{achievement.icon}</div>
                <p className="text-xs font-medium">{achievement.name}</p>
                {achievement.unlocked && (
                  <Badge variant="secondary" className="mt-2 text-xs">
                    Đã mở khóa
                  </Badge>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};