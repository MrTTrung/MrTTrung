import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon, Plus, Edit, Trash2, MapPin, Cloud } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { getEntriesByTripId, DiaryEntry } from "@/data/mockData";
import { useToast } from "@/hooks/use-toast";

interface DiaryManagerProps {
  tripId: string;
}

const moods = [
  { emoji: "😍", label: "Tuyệt vời" },
  { emoji: "😊", label: "Vui vẻ" },
  { emoji: "😌", label: "Thư giãn" },
  { emoji: "🤩", label: "Hào hứng" },
  { emoji: "😴", label: "Mệt mỏi" },
  { emoji: "🏖️", label: "Chill" },
  { emoji: "🤔", label: "Suy nghĩ" },
  { emoji: "😋", label: "Ngon miệng" }
];

export const DiaryManager = ({ tripId }: DiaryManagerProps) => {
  const [entries, setEntries] = useState<DiaryEntry[]>(getEntriesByTripId(tripId));
  const [showForm, setShowForm] = useState(false);
  const [editingEntry, setEditingEntry] = useState<DiaryEntry | null>(null);
  const [formData, setFormData] = useState({
    date: new Date(),
    text: "",
    mood: "😊",
    weather: "",
    location: "",
    images: [] as string[]
  });
  const { toast } = useToast();

  const resetForm = () => {
    setFormData({
      date: new Date(),
      text: "",
      mood: "😊",
      weather: "",
      location: "",
      images: []
    });
    setShowForm(false);
    setEditingEntry(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const newEntry: DiaryEntry = {
      id: editingEntry?.id || Date.now().toString(),
      tripId,
      date: formData.date.toISOString().split('T')[0],
      text: formData.text,
      mood: formData.mood,
      weather: formData.weather,
      location: formData.location,
      images: formData.images
    };

    if (editingEntry) {
      setEntries(entries.map(entry => entry.id === editingEntry.id ? newEntry : entry));
      toast({
        title: "Đã cập nhật",
        description: "Nhật ký đã được cập nhật thành công"
      });
    } else {
      setEntries([...entries, newEntry]);
      toast({
        title: "Đã thêm",
        description: "Nhật ký mới đã được thêm thành công"
      });
    }

    resetForm();
  };

  const handleEdit = (entry: DiaryEntry) => {
    setEditingEntry(entry);
    setFormData({
      date: new Date(entry.date),
      text: entry.text,
      mood: entry.mood,
      weather: entry.weather || "",
      location: entry.location || "",
      images: entry.images
    });
    setShowForm(true);
  };

  const handleDelete = (entryId: string) => {
    if (window.confirm("Bạn có chắc chắn muốn xóa nhật ký này?")) {
      setEntries(entries.filter(entry => entry.id !== entryId));
      toast({
        title: "Đã xóa",
        description: "Nhật ký đã được xóa thành công"
      });
    }
  };

  const addImage = () => {
    const url = prompt("Nhập URL hình ảnh:");
    if (url) {
      setFormData({
        ...formData,
        images: [...formData.images, url]
      });
    }
  };

  const removeImage = (index: number) => {
    setFormData({
      ...formData,
      images: formData.images.filter((_, i) => i !== index)
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Nhật ký chuyến đi</h2>
        <Button onClick={() => setShowForm(true)} variant="travel">
          <Plus className="w-4 h-4 mr-2" />
          Thêm nhật ký
        </Button>
      </div>

      {showForm && (
        <Card className="shadow-card-custom">
          <CardHeader>
            <CardTitle>
              {editingEntry ? "Chỉnh sửa nhật ký" : "Thêm nhật ký mới"}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Ngày</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left font-normal",
                          !formData.date && "text-muted-foreground"
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {format(formData.date, "dd/MM/yyyy")}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={formData.date}
                        onSelect={(date) => date && setFormData({ ...formData, date })}
                        initialFocus
                        className="pointer-events-auto"
                      />
                    </PopoverContent>
                  </Popover>
                </div>

                <div className="space-y-2">
                  <Label>Tâm trạng</Label>
                  <div className="grid grid-cols-4 gap-2">
                    {moods.map((mood) => (
                      <Button
                        key={mood.emoji}
                        type="button"
                        variant={formData.mood === mood.emoji ? "travel" : "outline"}
                        className="p-2 h-auto flex flex-col"
                        onClick={() => setFormData({ ...formData, mood: mood.emoji })}
                      >
                        <span className="text-lg">{mood.emoji}</span>
                        <span className="text-xs">{mood.label}</span>
                      </Button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="weather">Thời tiết</Label>
                  <Input
                    id="weather"
                    placeholder="VD: Nắng đẹp, 25°C"
                    value={formData.weather}
                    onChange={(e) => setFormData({ ...formData, weather: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="location">Địa điểm</Label>
                  <Input
                    id="location"
                    placeholder="VD: Hồ Xuân Hương"
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="text">Nội dung nhật ký</Label>
                <Textarea
                  id="text"
                  placeholder="Hãy chia sẻ về ngày hôm nay..."
                  value={formData.text}
                  onChange={(e) => setFormData({ ...formData, text: e.target.value })}
                  rows={4}
                  required
                />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label>Hình ảnh</Label>
                  <Button type="button" variant="outline" size="sm" onClick={addImage}>
                    <Plus className="w-4 h-4 mr-2" />
                    Thêm ảnh
                  </Button>
                </div>
                {formData.images.length > 0 && (
                  <div className="grid grid-cols-3 gap-2">
                    {formData.images.map((image, index) => (
                      <div key={index} className="relative group">
                        <img 
                          src={image} 
                          alt={`Ảnh ${index + 1}`}
                          className="w-full h-24 object-cover rounded"
                        />
                        <Button
                          type="button"
                          variant="destructive"
                          size="sm"
                          className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 p-1 h-auto"
                          onClick={() => removeImage(index)}
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="flex gap-4">
                <Button type="button" variant="outline" onClick={resetForm} className="flex-1">
                  Hủy
                </Button>
                <Button type="submit" variant="travel" className="flex-1">
                  {editingEntry ? "Cập nhật" : "Thêm nhật ký"}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Entry List */}
      <div className="space-y-4">
        {entries.length === 0 ? (
          <Card>
            <CardContent className="text-center py-12">
              <p className="text-muted-foreground mb-4">Chưa có nhật ký nào</p>
              <Button onClick={() => setShowForm(true)} variant="travel">
                <Plus className="w-4 h-4 mr-2" />
                Thêm nhật ký đầu tiên
              </Button>
            </CardContent>
          </Card>
        ) : (
          entries.map((entry) => (
            <Card key={entry.id} className="shadow-card-custom hover:shadow-travel transition-shadow duration-300">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{entry.mood}</span>
                    <div>
                      <CardTitle className="text-lg">
                        {new Date(entry.date).toLocaleDateString('vi-VN', {
                          weekday: 'long',
                          day: '2-digit',
                          month: '2-digit',
                          year: 'numeric'
                        })}
                      </CardTitle>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground mt-1">
                        {entry.location && (
                          <div className="flex items-center gap-1">
                            <MapPin className="w-3 h-3" />
                            <span>{entry.location}</span>
                          </div>
                        )}
                        {entry.weather && (
                          <div className="flex items-center gap-1">
                            <Cloud className="w-3 h-3" />
                            <span>{entry.weather}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" onClick={() => handleEdit(entry)}>
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button size="sm" variant="destructive" onClick={() => handleDelete(entry.id)}>
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-foreground leading-relaxed mb-4">{entry.text}</p>
                {entry.images.length > 0 && (
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                    {entry.images.map((image, index) => (
                      <img 
                        key={index}
                        src={image} 
                        alt={`Ảnh ${index + 1}`}
                        className="w-full h-32 object-cover rounded shadow-card-custom"
                      />
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
};