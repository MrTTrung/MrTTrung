import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Search, Filter, CalendarIcon, X, MapPin, Star } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { Trip } from "@/hooks/useSupabaseTrips";

interface SearchFilterProps {
  trips: Trip[];
  onFilteredTrips: (trips: Trip[]) => void;
}

export const SearchFilter = ({ trips, onFilteredTrips }: SearchFilterProps) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedLocation, setSelectedLocation] = useState("");
  const [selectedRating, setSelectedRating] = useState("");
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [dateRange, setDateRange] = useState<{ from?: Date; to?: Date }>({});
  const [showFilters, setShowFilters] = useState(false);

  // Get unique values for filters
  const uniqueLocations = Array.from(new Set(trips.map(trip => trip.location)));
  const uniqueTags = Array.from(new Set(trips.flatMap(trip => trip.tags)));
  const ratings = [1, 2, 3, 4, 5];

  const applyFilters = () => {
    let filtered = trips;

    // Search term
    if (searchTerm) {
      filtered = filtered.filter(trip => 
        trip.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        trip.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
        trip.notes.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Location filter
    if (selectedLocation) {
      filtered = filtered.filter(trip => trip.location === selectedLocation);
    }

    // Rating filter
    if (selectedRating) {
      filtered = filtered.filter(trip => trip.rating >= parseInt(selectedRating));
    }

    // Tags filter
    if (selectedTags.length > 0) {
      filtered = filtered.filter(trip => 
        selectedTags.every(tag => trip.tags.includes(tag))
      );
    }

    // Date range filter
    if (dateRange.from) {
      filtered = filtered.filter(trip => {
        const tripStart = new Date(trip.startDate);
        const tripEnd = new Date(trip.endDate);
        
        if (dateRange.to) {
          return tripStart >= dateRange.from! && tripEnd <= dateRange.to;
        } else {
          return tripStart >= dateRange.from!;
        }
      });
    }

    onFilteredTrips(filtered);
  };

  const clearFilters = () => {
    setSearchTerm("");
    setSelectedLocation("");
    setSelectedRating("");
    setSelectedTags([]);
    setDateRange({});
    onFilteredTrips(trips);
  };

  const toggleTag = (tag: string) => {
    if (selectedTags.includes(tag)) {
      setSelectedTags(selectedTags.filter(t => t !== tag));
    } else {
      setSelectedTags([...selectedTags, tag]);
    }
  };

  const hasActiveFilters = searchTerm || selectedLocation || selectedRating || selectedTags.length > 0 || dateRange.from;

  return (
    <div className="space-y-4">
      {/* Search Bar */}
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
          <Input
            placeholder="Tìm kiếm chuyến đi..."
            value={searchTerm}
            onChange={(e) => {
              setSearchTerm(e.target.value);
              applyFilters();
            }}
            className="pl-10"
          />
        </div>
        <Button
          variant={showFilters ? "travel" : "outline"}
          onClick={() => setShowFilters(!showFilters)}
        >
          <Filter className="w-4 h-4 mr-2" />
          Bộ lọc
        </Button>
        {hasActiveFilters && (
          <Button variant="ghost" onClick={clearFilters}>
            <X className="w-4 h-4 mr-2" />
            Xóa bộ lọc
          </Button>
        )}
      </div>

      {/* Active Filters Display */}
      {hasActiveFilters && (
        <div className="flex flex-wrap gap-2">
          {selectedLocation && (
            <Badge variant="secondary" className="gap-1">
              <MapPin className="w-3 h-3" />
              {selectedLocation}
              <button onClick={() => { setSelectedLocation(""); applyFilters(); }}>
                <X className="w-3 h-3" />
              </button>
            </Badge>
          )}
          {selectedRating && (
            <Badge variant="secondary" className="gap-1">
              <Star className="w-3 h-3" />
              {selectedRating}+ sao
              <button onClick={() => { setSelectedRating(""); applyFilters(); }}>
                <X className="w-3 h-3" />
              </button>
            </Badge>
          )}
          {selectedTags.map(tag => (
            <Badge key={tag} variant="secondary" className="gap-1">
              #{tag}
              <button onClick={() => { toggleTag(tag); applyFilters(); }}>
                <X className="w-3 h-3" />
              </button>
            </Badge>
          ))}
        </div>
      )}

      {/* Advanced Filters */}
      {showFilters && (
        <div className="bg-muted/50 p-4 rounded-lg space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Location Filter */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Địa điểm</label>
              <Select value={selectedLocation} onValueChange={(value) => { setSelectedLocation(value); applyFilters(); }}>
                <SelectTrigger>
                  <SelectValue placeholder="Tất cả địa điểm" />
                </SelectTrigger>
                <SelectContent>
                  {uniqueLocations.map(location => (
                    <SelectItem key={location} value={location}>
                      {location}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Rating Filter */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Đánh giá tối thiểu</label>
              <Select value={selectedRating} onValueChange={(value) => { setSelectedRating(value); applyFilters(); }}>
                <SelectTrigger>
                  <SelectValue placeholder="Tất cả đánh giá" />
                </SelectTrigger>
                <SelectContent>
                  {ratings.map(rating => (
                    <SelectItem key={rating} value={rating.toString()}>
                      {rating}+ sao
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Date Range */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Khoảng thời gian</label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !dateRange.from && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {dateRange.from ? (
                      dateRange.to ? (
                        <>
                          {format(dateRange.from, "dd/MM/yyyy")} -{" "}
                          {format(dateRange.to, "dd/MM/yyyy")}
                        </>
                      ) : (
                        format(dateRange.from, "dd/MM/yyyy")
                      )
                    ) : (
                      "Chọn khoảng thời gian"
                    )}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    initialFocus
                    mode="range"
                    defaultMonth={dateRange.from}
                    selected={dateRange.from && dateRange.to ? { from: dateRange.from, to: dateRange.to } : undefined}
                    onSelect={(range) => {
                      setDateRange(range || {});
                      applyFilters();
                    }}
                    numberOfMonths={2}
                    className="pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>

          {/* Tags Filter */}
          <div className="space-y-2">
            <label className="text-sm font-medium">Tags</label>
            <div className="flex flex-wrap gap-2">
              {uniqueTags.map(tag => (
                <Button
                  key={tag}
                  variant={selectedTags.includes(tag) ? "travel" : "outline"}
                  size="sm"
                  onClick={() => { toggleTag(tag); applyFilters(); }}
                >
                  #{tag}
                </Button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};