import { Button } from "@/components/ui/button";
import { PlusCircle, MapPin, Calendar, Camera } from "lucide-react";
import heroImage from "@/assets/travel-hero.jpg";

interface HeroSectionProps {
  onCreateTrip: () => void;
}

export const HeroSection = ({ onCreateTrip }: HeroSectionProps) => {
  return (
    <section className="relative overflow-hidden bg-gradient-hero py-20 px-4">
      <div className="absolute inset-0 opacity-20">
        <img 
          src={heroImage} 
          alt="Travel Journal" 
          className="w-full h-full object-cover"
        />
      </div>
      
      <div className="relative container mx-auto text-center text-white">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
            Lưu giữ mọi
            <span className="block bg-gradient-to-r from-yellow-200 to-orange-200 bg-clip-text text-transparent">
              khoảnh khắc du lịch
            </span>
          </h1>
          
          <p className="text-xl md:text-2xl mb-8 text-white/90 max-w-2xl mx-auto leading-relaxed">
            Viết nhật ký, lưu ảnh đẹp, ghi chú chi phí và khám phá lại hành trình của bạn qua bản đồ tương tác
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
            <Button 
              variant="secondary" 
              size="lg"
              onClick={onCreateTrip}
              className="gap-3 text-lg px-8 py-6 shadow-xl hover:shadow-2xl transform hover:scale-105 transition-all duration-300"
            >
              <PlusCircle className="w-6 h-6" />
              Bắt đầu chuyến đi mới
            </Button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-3xl mx-auto">
            <div className="flex flex-col items-center gap-3 text-center">
              <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center">
                <Calendar className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-lg font-semibold">Nhật ký hằng ngày</h3>
              <p className="text-white/80 text-sm">Ghi lại cảm xúc và trải nghiệm trong từng ngày du lịch</p>
            </div>
            
            <div className="flex flex-col items-center gap-3 text-center">
              <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center">
                <Camera className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-lg font-semibold">Lưu ảnh kỷ niệm</h3>
              <p className="text-white/80 text-sm">Tạo album ảnh đẹp và tổ chức theo từng chuyến đi</p>
            </div>
            
            <div className="flex flex-col items-center gap-3 text-center">
              <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center">
                <MapPin className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-lg font-semibold">Bản đồ hành trình</h3>
              <p className="text-white/80 text-sm">Theo dõi và xem lại hành trình trên bản đồ tương tác</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};