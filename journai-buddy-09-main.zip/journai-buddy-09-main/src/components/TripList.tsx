import { useState } from "react";
import { TripCard } from "./TripCard";
import { SearchFilter } from "./SearchFilter";
import { Trip } from "@/hooks/useSupabaseTrips";
import { MapPin } from "lucide-react";

interface TripListProps {
  onViewTrip: (tripId: string) => void;
  trips?: Trip[];
}

export const TripList = ({ onViewTrip, trips = [] }: TripListProps) => {
  const [filteredTrips, setFilteredTrips] = useState<Trip[]>(trips);

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-foreground mb-2">Các chuyến đi của bạn</h2>
        <p className="text-muted-foreground">
          {filteredTrips.length} chuyến đi đã khám phá
        </p>
      </div>
      
      <div className="mb-6">
        <SearchFilter trips={trips} onFilteredTrips={setFilteredTrips} />
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredTrips.map((trip) => (
          <TripCard 
            key={trip.id}
            trip={trip}
            onViewTrip={onViewTrip}
          />
        ))}
      </div>
      
      {filteredTrips.length === 0 && trips.length > 0 && (
        <div className="text-center py-16">
          <div className="w-24 h-24 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
            <MapPin className="w-12 h-12 text-muted-foreground" />
          </div>
          <h3 className="text-xl font-semibold text-foreground mb-2">
            Không tìm thấy chuyến đi nào
          </h3>
          <p className="text-muted-foreground">
            Thử thay đổi bộ lọc để tìm kiếm chuyến đi khác
          </p>
        </div>
      )}
      
      {trips.length === 0 && (
        <div className="text-center py-16">
          <div className="w-24 h-24 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
            <MapPin className="w-12 h-12 text-muted-foreground" />
          </div>
          <h3 className="text-xl font-semibold text-foreground mb-2">
            Chưa có chuyến đi nào
          </h3>
          <p className="text-muted-foreground">
            Hãy tạo chuyến đi đầu tiên của bạn!
          </p>
        </div>
      )}
    </div>
  );
};