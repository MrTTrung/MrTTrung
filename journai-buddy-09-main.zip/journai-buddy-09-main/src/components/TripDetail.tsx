import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowLeft, MapPin, Calendar, Star, Plus, Edit, Trash2 } from "lucide-react";
import { getEntriesByTripId, getExpensesByTripId, getTotalExpensesByTrip, formatCurrency } from "@/data/mockData";
import { Trip } from "@/hooks/useSupabaseTrips";
import { DiaryManager } from "./DiaryManager";
import { ExpenseManager } from "./ExpenseManager";
import { useToast } from "@/hooks/use-toast";

interface TripDetailProps {
  trip: Trip;
  onBack: () => void;
  onEditTrip?: (trip: Trip) => void;
  onDeleteTrip?: (tripId: string) => void;
}

export const TripDetail = ({ trip, onBack, onEditTrip, onDeleteTrip }: TripDetailProps) => {
  const [activeTab, setActiveTab] = useState("overview");
  const { toast } = useToast();
  
  const diaryEntries = getEntriesByTripId(trip.id);
  const expenses = getExpensesByTripId(trip.id);
  const totalExpenses = getTotalExpensesByTrip(trip.id);

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('vi-VN', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, index) => (
      <Star
        key={index}
        className={`w-5 h-5 ${
          index < rating ? "fill-secondary text-secondary" : "text-muted-foreground"
        }`}
      />
    ));
  };

  const handleDelete = () => {
    if (window.confirm("Bạn có chắc chắn muốn xóa chuyến đi này?")) {
      onDeleteTrip?.(trip.id);
      toast({
        title: "Đã xóa",
        description: "Chuyến đi đã được xóa thành công"
      });
      onBack();
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="mb-6">
        <Button variant="ghost" onClick={onBack} className="mb-4">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Quay lại
        </Button>
      </div>

      {/* Hero Section */}
      <Card className="overflow-hidden shadow-travel mb-6">
        <div className="relative">
          <div 
            className="h-64 bg-cover bg-center bg-gradient-primary"
            style={{ 
              backgroundImage: trip.cover_image ? `url(${trip.cover_image})` : undefined 
            }}
          />
          <div className="absolute inset-0 bg-black/30" />
          <div className="absolute top-4 right-4 flex gap-2">
            {onEditTrip && (
              <Button size="sm" variant="secondary" onClick={() => onEditTrip(trip)}>
                <Edit className="w-4 h-4" />
              </Button>
            )}
            {onDeleteTrip && (
              <Button size="sm" variant="destructive" onClick={handleDelete}>
                <Trash2 className="w-4 h-4" />
              </Button>
            )}
          </div>
          <div className="absolute bottom-6 left-6 text-white">
            <h1 className="text-4xl font-bold mb-2">{trip.title}</h1>
            <div className="flex items-center gap-4 text-white/90">
              <div className="flex items-center gap-2">
                <MapPin className="w-5 h-5" />
                <span>{trip.location}</span>
              </div>
              <div className="flex items-center gap-2">
                <Calendar className="w-5 h-5" />
                <span>{formatDate(trip.startDate)} - {formatDate(trip.endDate)}</span>
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Tabs Navigation */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4 mb-6">
          <TabsTrigger value="overview">Tổng quan</TabsTrigger>
          <TabsTrigger value="diary">Nhật ký ({diaryEntries.length})</TabsTrigger>
          <TabsTrigger value="expenses">Chi phí ({expenses.length})</TabsTrigger>
          <TabsTrigger value="photos">Hình ảnh</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  Thông tin chuyến đi
                  <div className="flex items-center gap-1">
                    {renderStars(trip.rating)}
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-muted-foreground leading-relaxed">{trip.notes}</p>
                <div className="flex flex-wrap gap-2">
                  {trip.tags.map((tag) => (
                    <Badge key={tag} variant="secondary">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            <div className="space-y-4">
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg">Thống kê</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Số ngày:</span>
                    <span className="font-medium">
                      {Math.ceil((new Date(trip.endDate).getTime() - new Date(trip.startDate).getTime()) / (1000 * 60 * 60 * 24)) + 1}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Nhật ký:</span>
                    <span className="font-medium">{diaryEntries.length} mục</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Chi phí:</span>
                    <span className="font-medium">{formatCurrency(totalExpenses)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Đánh giá:</span>
                    <div className="flex items-center gap-1">
                      {renderStars(trip.rating)}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* Diary Tab */}
        <TabsContent value="diary">
          <DiaryManager tripId={trip.id} />
        </TabsContent>

        {/* Expenses Tab */}
        <TabsContent value="expenses">
          <ExpenseManager tripId={trip.id} />
        </TabsContent>

        {/* Photos Tab */}
        <TabsContent value="photos">
          <Card>
            <CardHeader>
              <CardTitle>Hình ảnh chuyến đi</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {diaryEntries.map((entry) => 
                  entry.images.map((image, index) => (
                    <div key={`${entry.id}-${index}`} className="aspect-square">
                      <img 
                        src={image} 
                        alt={`Hình ảnh ${entry.date}`}
                        className="w-full h-full object-cover rounded-lg shadow-card-custom hover:shadow-travel transition-shadow duration-300"
                      />
                    </div>
                  ))
                )}
                {trip.cover_image && (
                  <div className="aspect-square">
                    <img 
                      src={trip.cover_image} 
                      alt="Cover"
                      className="w-full h-full object-cover rounded-lg shadow-card-custom hover:shadow-travel transition-shadow duration-300"
                    />
                  </div>
                )}
              </div>
              {diaryEntries.length === 0 && (
                <div className="text-center py-12">
                  <p className="text-muted-foreground">Chưa có hình ảnh nào được thêm</p>
                  <Button variant="travel" className="mt-4" onClick={() => setActiveTab("diary")}>
                    <Plus className="w-4 h-4 mr-2" />
                    Thêm nhật ký đầu tiên
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};