import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Camera, 
  Heart, 
  Share2, 
  Download, 
  MapPin, 
  Calendar, 
  Tag,
  Grid3X3,
  List,
  Search,
  Filter,
  Upload,
  Star,
  X
} from "lucide-react";
import { mockTrips, mockDiaryEntries } from "@/data/mockData";

interface Photo {
  id: string;
  url: string;
  title: string;
  tripId: string;
  tripTitle: string;
  location: string;
  date: string;
  tags: string[];
  liked: boolean;
  description?: string;
}

export const PhotoGallery = () => {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [selectedPhoto, setSelectedPhoto] = useState<Photo | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTrip, setSelectedTrip] = useState<string>('all');
  const [selectedTag, setSelectedTag] = useState<string>('all');

  // Mock photo data based on diary entries
  const photos: Photo[] = mockDiaryEntries.flatMap(entry => 
    entry.images.map((image, index) => {
      const trip = mockTrips.find(t => t.id === entry.tripId);
      return {
        id: `${entry.id}-${index}`,
        url: image,
        title: `${trip?.title} - ${entry.date}`,
        tripId: entry.tripId,
        tripTitle: trip?.title || '',
        location: entry.location || trip?.location || '',
        date: entry.date,
        tags: trip?.tags || [],
        liked: Math.random() > 0.5,
        description: entry.text.slice(0, 100) + '...'
      };
    })
  );

  // Add some additional mock photos
  const additionalPhotos: Photo[] = [
    {
      id: 'extra-1',
      url: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=600',
      title: 'Hoàng hôn Đà Lạt',
      tripId: '1',
      tripTitle: 'Hành trình Đà Lạt đáng nhớ',
      location: 'Đà Lạt, Lâm Đồng',
      date: '2024-06-21',
      tags: ['hoàng hôn', 'núi', 'lãng mạn'],
      liked: true,
      description: 'Hoàng hôn tuyệt đẹp nhìn từ đỉnh Langbiang'
    },
    {
      id: 'extra-2',
      url: 'https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=600',
      title: 'Bãi biển Phú Quốc',
      tripId: '2',
      tripTitle: 'Phú Quốc - Thiên đường biển đảo',
      location: 'Phú Quốc, Kiên Giang',
      date: '2024-08-11',
      tags: ['biển', 'sunset', 'thư giãn'],
      liked: false,
      description: 'Bãi Sao với cát trắng mịn và nước biển trong xanh'
    },
    {
      id: 'extra-3',
      url: 'https://images.unsplash.com/photo-1583417319070-4a69db38a482?w=600',
      title: 'Phố cổ Hà Nội',
      tripId: '3',
      tripTitle: 'Hà Nội - Nơi lưu giữ nét xưa',
      location: 'Hà Nội',
      date: '2024-10-02',
      tags: ['văn hóa', 'phố cổ', 'lịch sử'],
      liked: true,
      description: 'Những con phố cổ kính với kiến trúc Pháp cổ'
    }
  ];

  const allPhotos = [...photos, ...additionalPhotos];

  const filteredPhotos = allPhotos.filter(photo => {
    const matchesSearch = photo.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         photo.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         photo.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesTrip = selectedTrip === 'all' || photo.tripId === selectedTrip;
    const matchesTag = selectedTag === 'all' || photo.tags.includes(selectedTag);
    
    return matchesSearch && matchesTrip && matchesTag;
  });

  const allTags = Array.from(new Set(allPhotos.flatMap(photo => photo.tags)));
  const likedPhotos = allPhotos.filter(photo => photo.liked);

  const toggleLike = (photoId: string) => {
    // In real app, this would update the backend
    console.log('Toggle like for photo:', photoId);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-foreground mb-2">Thư viện ảnh</h2>
        <p className="text-muted-foreground">
          {allPhotos.length} ảnh từ {mockTrips.length} chuyến đi
        </p>
      </div>

      <Tabs defaultValue="all" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="all">Tất cả ({allPhotos.length})</TabsTrigger>
          <TabsTrigger value="liked">Yêu thích ({likedPhotos.length})</TabsTrigger>
          <TabsTrigger value="recent">Gần đây</TabsTrigger>
          <TabsTrigger value="upload">Tải lên</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-6">
          {/* Filters and Search */}
          <Card className="shadow-card-custom">
            <CardContent className="p-4">
              <div className="flex flex-col md:flex-row gap-4 items-center">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    placeholder="Tìm kiếm ảnh, địa điểm, tag..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
                
                <select
                  className="px-3 py-2 border border-input rounded-md text-sm"
                  value={selectedTrip}
                  onChange={(e) => setSelectedTrip(e.target.value)}
                >
                  <option value="all">Tất cả chuyến đi</option>
                  {mockTrips.map(trip => (
                    <option key={trip.id} value={trip.id}>{trip.title}</option>
                  ))}
                </select>

                <select
                  className="px-3 py-2 border border-input rounded-md text-sm"
                  value={selectedTag}
                  onChange={(e) => setSelectedTag(e.target.value)}
                >
                  <option value="all">Tất cả tag</option>
                  {allTags.map(tag => (
                    <option key={tag} value={tag}>{tag}</option>
                  ))}
                </select>

                <div className="flex gap-2">
                  <Button
                    variant={viewMode === 'grid' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setViewMode('grid')}
                  >
                    <Grid3X3 className="w-4 h-4" />
                  </Button>
                  <Button
                    variant={viewMode === 'list' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setViewMode('list')}
                  >
                    <List className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Photo Grid */}
          {viewMode === 'grid' ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
              {filteredPhotos.map(photo => (
                <Card
                  key={photo.id}
                  className="group cursor-pointer overflow-hidden hover:shadow-travel transition-all duration-300"
                  onClick={() => setSelectedPhoto(photo)}
                >
                  <div className="relative aspect-square">
                    <img
                      src={photo.url}
                      alt={photo.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300" />
                    
                    <Button
                      variant="ghost"
                      size="sm"
                      className="absolute top-2 right-2 p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleLike(photo.id);
                      }}
                    >
                      <Heart className={`w-4 h-4 ${photo.liked ? 'fill-red-500 text-red-500' : 'text-white'}`} />
                    </Button>

                    <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-3 opacity-0 group-hover:opacity-100 transition-opacity">
                      <p className="text-white text-sm font-medium truncate">{photo.title}</p>
                      <p className="text-white/80 text-xs flex items-center gap-1">
                        <MapPin className="w-3 h-3" />
                        {photo.location}
                      </p>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          ) : (
            <div className="space-y-4">
              {filteredPhotos.map(photo => (
                <Card key={photo.id} className="shadow-card-custom hover:shadow-travel transition-shadow duration-300">
                  <CardContent className="p-4">
                    <div className="flex gap-4">
                      <img
                        src={photo.url}
                        alt={photo.title}
                        className="w-24 h-24 object-cover rounded-lg cursor-pointer"
                        onClick={() => setSelectedPhoto(photo)}
                      />
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold mb-2">{photo.title}</h3>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground mb-2">
                          <span className="flex items-center gap-1">
                            <MapPin className="w-3 h-3" />
                            {photo.location}
                          </span>
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            {new Date(photo.date).toLocaleDateString('vi-VN')}
                          </span>
                        </div>
                        <p className="text-sm text-muted-foreground mb-3">{photo.description}</p>
                        <div className="flex items-center gap-2 flex-wrap">
                          {photo.tags.slice(0, 3).map(tag => (
                            <Badge key={tag} variant="outline" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                          {photo.tags.length > 3 && (
                            <Badge variant="outline" className="text-xs">
                              +{photo.tags.length - 3}
                            </Badge>
                          )}
                        </div>
                      </div>
                      <div className="flex flex-col gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => toggleLike(photo.id)}
                        >
                          <Heart className={`w-4 h-4 ${photo.liked ? 'fill-red-500 text-red-500' : ''}`} />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Share2 className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Download className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          {filteredPhotos.length === 0 && (
            <Card className="shadow-card-custom">
              <CardContent className="p-16 text-center">
                <Camera className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-xl font-semibold mb-2">Không tìm thấy ảnh nào</h3>
                <p className="text-muted-foreground">
                  Thử thay đổi bộ lọc hoặc từ khóa tìm kiếm
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="liked" className="space-y-6">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
            {likedPhotos.map(photo => (
              <Card
                key={photo.id}
                className="group cursor-pointer overflow-hidden hover:shadow-travel transition-all duration-300"
                onClick={() => setSelectedPhoto(photo)}
              >
                <div className="relative aspect-square">
                  <img
                    src={photo.url}
                    alt={photo.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-2 right-2">
                    <Heart className="w-5 h-5 fill-red-500 text-red-500" />
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="recent">
          <Card className="shadow-card-custom">
            <CardContent className="p-16 text-center">
              <Camera className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
              <h3 className="text-xl font-semibold mb-2">Ảnh gần đây</h3>
              <p className="text-muted-foreground">
                Hiển thị các ảnh được thêm trong 30 ngày gần đây
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="upload">
          <Card className="shadow-card-custom">
            <CardContent className="p-16 text-center">
              <Upload className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
              <h3 className="text-xl font-semibold mb-2">Tải lên ảnh mới</h3>
              <p className="text-muted-foreground mb-4">
                Chọn ảnh từ thiết bị của bạn để thêm vào thư viện
              </p>
              <Button>
                <Upload className="w-4 h-4 mr-2" />
                Chọn ảnh
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Photo Detail Modal */}
      <Dialog open={!!selectedPhoto} onOpenChange={() => setSelectedPhoto(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-auto">
          {selectedPhoto && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center justify-between">
                  <span>{selectedPhoto.title}</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setSelectedPhoto(null)}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </DialogTitle>
              </DialogHeader>
              
              <div className="space-y-4">
                <img
                  src={selectedPhoto.url}
                  alt={selectedPhoto.title}
                  className="w-full max-h-96 object-contain rounded-lg"
                />
                
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <p className="flex items-center gap-2 text-sm text-muted-foreground">
                      <MapPin className="w-4 h-4" />
                      {selectedPhoto.location}
                    </p>
                    <p className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Calendar className="w-4 h-4" />
                      {new Date(selectedPhoto.date).toLocaleDateString('vi-VN')}
                    </p>
                  </div>
                  
                  <div className="flex gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => toggleLike(selectedPhoto.id)}
                    >
                      <Heart className={`w-4 h-4 ${selectedPhoto.liked ? 'fill-red-500 text-red-500' : ''}`} />
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Share2 className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Download className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
                
                {selectedPhoto.description && (
                  <p className="text-sm">{selectedPhoto.description}</p>
                )}
                
                <div className="flex flex-wrap gap-2">
                  {selectedPhoto.tags.map(tag => (
                    <Badge key={tag} variant="outline">
                      <Tag className="w-3 h-3 mr-1" />
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};