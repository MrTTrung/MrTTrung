import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, MapPin, Star, Eye } from "lucide-react";
import { Trip } from "@/hooks/useSupabaseTrips";

interface TripCardProps {
  trip: Trip;
  onViewTrip: (tripId: string) => void;
}

export const TripCard = ({ trip, onViewTrip }: TripCardProps) => {
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('vi-VN', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, index) => (
      <Star
        key={index}
        className={`w-4 h-4 ${
          index < rating ? "fill-secondary text-secondary" : "text-muted-foreground"
        }`}
      />
    ));
  };

  return (
    <Card className="group overflow-hidden shadow-card-custom hover:shadow-travel transition-all duration-300 hover:-translate-y-2">
      <div className="relative">
        <div 
          className="h-48 bg-cover bg-center bg-gradient-primary"
          style={{ 
            backgroundImage: trip.coverImage ? `url(${trip.coverImage})` : undefined 
          }}
        />
        <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors duration-300" />
        <div className="absolute top-4 right-4">
          <div className="flex items-center gap-1 bg-white/90 backdrop-blur-sm px-2 py-1 rounded-full">
            {renderStars(trip.rating)}
          </div>
        </div>
      </div>
      
      <CardHeader className="pb-3">
        <CardTitle className="text-xl font-bold text-foreground group-hover:text-primary transition-colors duration-200">
          {trip.title}
        </CardTitle>
        <div className="flex items-center gap-2 text-muted-foreground">
          <MapPin className="w-4 h-4" />
          <span className="text-sm">{trip.location}</span>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Calendar className="w-4 h-4" />
          <span>{formatDate(trip.startDate)} - {formatDate(trip.endDate)}</span>
        </div>
        
        <p className="text-sm text-muted-foreground line-clamp-2">{trip.notes}</p>
        
        <div className="flex flex-wrap gap-2">
          {trip.tags.slice(0, 3).map((tag) => (
            <Badge key={tag} variant="secondary" className="text-xs">
              {tag}
            </Badge>
          ))}
          {trip.tags.length > 3 && (
            <Badge variant="outline" className="text-xs">
              +{trip.tags.length - 3}
            </Badge>
          )}
        </div>
        
        <Button 
          variant="travel" 
          className="w-full group/btn"
          onClick={() => onViewTrip(trip.id)}
        >
          <Eye className="w-4 h-4 group-hover/btn:scale-110 transition-transform duration-200" />
          Xem chi tiết
        </Button>
      </CardContent>
    </Card>
  );
};