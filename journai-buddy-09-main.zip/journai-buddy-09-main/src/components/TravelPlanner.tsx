import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  MapPin, 
  Calendar, 
  Clock, 
  Plus, 
  Trash2, 
  Edit,
  CheckCircle2,
  AlertCircle,
  Star,
  Camera,
  Utensils,
  Bed,
  Lightbulb,
  Heart,
  Wallet
} from "lucide-react";

interface ItineraryItem {
  id: string;
  time: string;
  activity: string;
  location: string;
  type: 'transport' | 'attraction' | 'food' | 'accommodation' | 'other';
  notes?: string;
  completed?: boolean;
  priority: 'low' | 'medium' | 'high';
}

interface PackingItem {
  id: string;
  name: string;
  category: string;
  packed: boolean;
  essential: boolean;
}

export const TravelPlanner = () => {
  const [activeDay, setActiveDay] = useState(1);
  const [itinerary, setItinerary] = useState<Record<number, ItineraryItem[]>>({
    1: [
      {
        id: '1',
        time: '08:00',
        activity: 'Bay từ TP.HCM đến Đà Lạt',
        location: 'Sân bay Liên Khương',
        type: 'transport',
        priority: 'high',
        completed: true
      },
      {
        id: '2',
        time: '10:30',
        activity: 'Check-in khách sạn',
        location: 'Hotel Grand Dalat',
        type: 'accommodation',
        priority: 'high',
        completed: true
      },
      {
        id: '3',
        time: '14:00',
        activity: 'Tham quan Chợ Đà Lạt',
        location: 'Chợ Đà Lạt',
        type: 'attraction',
        priority: 'medium',
        completed: false
      },
      {
        id: '4',
        time: '18:00',
        activity: 'Ăn tối tại nhà hàng địa phương',
        location: 'Góc Hà Thành',
        type: 'food',
        priority: 'medium',
        completed: false
      }
    ]
  });

  const [packingList, setPackingList] = useState<PackingItem[]>([
    { id: '1', name: 'Áo khoác ấm', category: 'Quần áo', packed: true, essential: true },
    { id: '2', name: 'Giày đi bộ', category: 'Giày dép', packed: false, essential: true },
    { id: '3', name: 'Máy ảnh', category: 'Điện tử', packed: false, essential: false },
    { id: '4', name: 'Thuốc cảm', category: 'Y tế', packed: true, essential: true },
    { id: '5', name: 'Kem chống nắng', category: 'Chăm sóc cá nhân', packed: false, essential: false }
  ]);

  const [newActivity, setNewActivity] = useState({
    time: '',
    activity: '',
    location: '',
    type: 'other' as ItineraryItem['type'],
    priority: 'medium' as ItineraryItem['priority']
  });

  const [newPackingItem, setNewPackingItem] = useState({
    name: '',
    category: '',
    essential: false
  });

  const getTypeIcon = (type: ItineraryItem['type']) => {
    switch (type) {
      case 'transport': return '🚗';
      case 'attraction': return '🎯';
      case 'food': return '🍽️';
      case 'accommodation': return '🏨';
      default: return '📍';
    }
  };

  const getPriorityColor = (priority: ItineraryItem['priority']) => {
    switch (priority) {
      case 'high': return 'destructive';
      case 'medium': return 'secondary';
      case 'low': return 'outline';
    }
  };

  const addActivity = () => {
    if (!newActivity.activity || !newActivity.time) return;
    
    const activity: ItineraryItem = {
      id: Date.now().toString(),
      ...newActivity,
      completed: false
    };

    setItinerary(prev => ({
      ...prev,
      [activeDay]: [...(prev[activeDay] || []), activity]
    }));

    setNewActivity({
      time: '',
      activity: '',
      location: '',
      type: 'other',
      priority: 'medium'
    });
  };

  const toggleActivity = (dayNumber: number, activityId: string) => {
    setItinerary(prev => ({
      ...prev,
      [dayNumber]: prev[dayNumber]?.map(item =>
        item.id === activityId ? { ...item, completed: !item.completed } : item
      ) || []
    }));
  };

  const addPackingItem = () => {
    if (!newPackingItem.name) return;
    
    const item: PackingItem = {
      id: Date.now().toString(),
      ...newPackingItem,
      packed: false
    };

    setPackingList(prev => [...prev, item]);
    setNewPackingItem({ name: '', category: '', essential: false });
  };

  const togglePackingItem = (itemId: string) => {
    setPackingList(prev =>
      prev.map(item =>
        item.id === itemId ? { ...item, packed: !item.packed } : item
      )
    );
  };

  const categories = Array.from(new Set(packingList.map(item => item.category)));
  const packedItems = packingList.filter(item => item.packed).length;
  const packingProgress = (packedItems / packingList.length) * 100;

  const days = Array.from({ length: 5 }, (_, i) => i + 1);

  // Travel suggestions data
  const travelSuggestions = [
    {
      id: 1,
      title: "Đà Nẵng - Hội An",
      duration: "3-4 ngày",
      budget: "2,500,000 - 4,000,000 VND",
      season: "Tháng 2-8",
      description: "Kết hợp giữa thành phố hiện đại và phố cổ thơ mộng",
      highlights: [
        "Cầu Vàng Ba Na Hills",
        "Phố cổ Hội An", 
        "Bãi biển Mỹ Khê",
        "Đèn lồng rực rỡ"
      ],
      tips: [
        "Thuê xe máy để di chuyển dễ dàng",
        "Thử bánh mì Phượng và cao lầu",
        "Chụp ảnh đẹp vào buổi chiều tối"
      ]
    },
    {
      id: 2,
      title: "Sa Pa - Lào Cai", 
      duration: "2-3 ngày",
      budget: "1,800,000 - 3,200,000 VND",
      season: "Tháng 9-11, 3-5",
      description: "Ruộng bậc thang và văn hóa dân tộc độc đáo",
      highlights: [
        "Ruộng bậc thang Mù Cang Chải",
        "Đỉnh Fansipan",
        "Chợ tình Sa Pa",
        "Bản làng dân tộc"
      ],
      tips: [
        "Mang áo ấm, thời tiết se lạnh",
        "Trekking cần giày chống trượt",
        "Thuê hướng dẫn viên địa phương"
      ]
    },
    {
      id: 3,
      title: "Phú Quốc",
      duration: "4-5 ngày", 
      budget: "3,000,000 - 6,000,000 VND",
      season: "Tháng 11-3",
      description: "Đảo ngọc với biển xanh và hải sản tươi ngon",
      highlights: [
        "Cáp treo Hòn Thơm",
        "Safari Phú Quốc",
        "Chợ đêm Dinh Cậu",
        "Sunset Sanato Beach Club"
      ],
      tips: [
        "Book resort trước cao điểm",
        "Thuê xe máy khám phá đảo",
        "Thử nước mắm Phú Quốc"
      ]
    },
    {
      id: 4,
      title: "Ninh Bình",
      duration: "2-3 ngày",
      budget: "1,500,000 - 2,800,000 VND", 
      season: "Tháng 3-5, 9-11",
      description: "Vịnh Hạ Long trên cạn với động Phong Nha huyền bí",
      highlights: [
        "Tràng An - di sản thế giới",
        "Tam Cốc Bích Động",
        "Động Phong Nha",
        "Núi Múa view đẹp"
      ],
      tips: [
        "Đi thuyền buổi sáng tránh nóng",
        "Mang nón, kem chống nắng",
        "Thử cơm cháy chấm nước mắm"
      ]
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-foreground mb-2">Lập kế hoạch chuyến đi</h2>
        <p className="text-muted-foreground">
          Tổ chức chi tiết cho chuyến đi hoàn hảo
        </p>
      </div>

      <Tabs defaultValue="itinerary" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="itinerary">Lịch trình</TabsTrigger>
          <TabsTrigger value="packing">Chuẩn bị đồ</TabsTrigger>
          <TabsTrigger value="suggestions">Gợi ý</TabsTrigger>
          <TabsTrigger value="budget">Ngân sách</TabsTrigger>
        </TabsList>

        <TabsContent value="itinerary" className="space-y-6">
          {/* Day Navigation */}
          <div className="flex gap-2 flex-wrap">
            {days.map(day => (
              <Button
                key={day}
                variant={activeDay === day ? "default" : "outline"}
                onClick={() => setActiveDay(day)}
                className="gap-2"
              >
                <Calendar className="w-4 h-4" />
                Ngày {day}
              </Button>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Add New Activity */}
            <Card className="shadow-card-custom">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Plus className="w-5 h-5" />
                  Thêm hoạt động
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-2">
                  <Input
                    placeholder="Thời gian (VD: 14:00)"
                    value={newActivity.time}
                    onChange={(e) => setNewActivity(prev => ({ ...prev, time: e.target.value }))}
                  />
                  <select
                    className="px-3 py-2 border border-input rounded-md text-sm"
                    value={newActivity.type}
                    onChange={(e) => setNewActivity(prev => ({ ...prev, type: e.target.value as ItineraryItem['type'] }))}
                  >
                    <option value="attraction">Tham quan</option>
                    <option value="food">Ăn uống</option>
                    <option value="transport">Di chuyển</option>
                    <option value="accommodation">Lưu trú</option>
                    <option value="other">Khác</option>
                  </select>
                </div>
                <Input
                  placeholder="Hoạt động"
                  value={newActivity.activity}
                  onChange={(e) => setNewActivity(prev => ({ ...prev, activity: e.target.value }))}
                />
                <Input
                  placeholder="Địa điểm"
                  value={newActivity.location}
                  onChange={(e) => setNewActivity(prev => ({ ...prev, location: e.target.value }))}
                />
                <select
                  className="w-full px-3 py-2 border border-input rounded-md text-sm"
                  value={newActivity.priority}
                  onChange={(e) => setNewActivity(prev => ({ ...prev, priority: e.target.value as ItineraryItem['priority'] }))}
                >
                  <option value="low">Ưu tiên thấp</option>
                  <option value="medium">Ưu tiên trung bình</option>
                  <option value="high">Ưu tiên cao</option>
                </select>
                <Button onClick={addActivity} className="w-full">
                  Thêm hoạt động
                </Button>
              </CardContent>
            </Card>

            {/* Itinerary for Selected Day */}
            <Card className="lg:col-span-2 shadow-card-custom">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="w-5 h-5" />
                  Lịch trình ngày {activeDay}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {(itinerary[activeDay] || []).map((item, index) => (
                    <div
                      key={item.id}
                      className={`flex items-start gap-4 p-4 rounded-lg border transition-all duration-300 ${
                        item.completed ? 'bg-muted border-accent' : 'bg-card'
                      }`}
                    >
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => toggleActivity(activeDay, item.id)}
                        className="p-1"
                      >
                        {item.completed ? (
                          <CheckCircle2 className="w-5 h-5 text-accent" />
                        ) : (
                          <div className="w-5 h-5 border-2 border-muted-foreground rounded-full" />
                        )}
                      </Button>
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="text-2xl">{getTypeIcon(item.type)}</span>
                          <Badge variant={getPriorityColor(item.priority)} className="text-xs">
                            {item.priority === 'high' ? 'Cao' : item.priority === 'medium' ? 'TB' : 'Thấp'}
                          </Badge>
                          <span className="text-sm font-medium">{item.time}</span>
                        </div>
                        <h4 className={`font-semibold ${item.completed ? 'line-through text-muted-foreground' : ''}`}>
                          {item.activity}
                        </h4>
                        <p className="text-sm text-muted-foreground flex items-center gap-1 mt-1">
                          <MapPin className="w-3 h-3" />
                          {item.location}
                        </p>
                      </div>
                      
                      <Button variant="ghost" size="sm" className="p-1">
                        <Edit className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                  
                  {(!itinerary[activeDay] || itinerary[activeDay].length === 0) && (
                    <div className="text-center py-8 text-muted-foreground">
                      <Clock className="w-12 h-12 mx-auto mb-4 opacity-50" />
                      <p>Chưa có hoạt động nào cho ngày này</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="packing" className="space-y-6">
          <Card className="shadow-card-custom">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5" />
                  Tiến độ chuẩn bị
                </span>
                <span className="text-sm text-muted-foreground">
                  {packedItems}/{packingList.length} món đồ
                </span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Progress value={packingProgress} className="mb-4" />
              <p className="text-sm text-muted-foreground">
                {Math.round(packingProgress)}% hoàn thành
              </p>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Add New Item */}
            <Card className="shadow-card-custom">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Plus className="w-5 h-5" />
                  Thêm đồ dùng
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Input
                  placeholder="Tên đồ dùng"
                  value={newPackingItem.name}
                  onChange={(e) => setNewPackingItem(prev => ({ ...prev, name: e.target.value }))}
                />
                <Input
                  placeholder="Danh mục"
                  value={newPackingItem.category}
                  onChange={(e) => setNewPackingItem(prev => ({ ...prev, category: e.target.value }))}
                />
                <label className="flex items-center gap-2 text-sm">
                  <input
                    type="checkbox"
                    checked={newPackingItem.essential}
                    onChange={(e) => setNewPackingItem(prev => ({ ...prev, essential: e.target.checked }))}
                  />
                  Đồ dùng thiết yếu
                </label>
                <Button onClick={addPackingItem} className="w-full">
                  Thêm vào danh sách
                </Button>
              </CardContent>
            </Card>

            {/* Packing List by Category */}
            <div className="lg:col-span-3 space-y-4">
              {categories.map(category => {
                const categoryItems = packingList.filter(item => item.category === category);
                const packedInCategory = categoryItems.filter(item => item.packed).length;
                
                return (
                  <Card key={category} className="shadow-card-custom">
                    <CardHeader>
                      <CardTitle className="flex items-center justify-between">
                        <span>{category}</span>
                        <Badge variant="outline">
                          {packedInCategory}/{categoryItems.length}
                        </Badge>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                        {categoryItems.map(item => (
                          <div
                            key={item.id}
                            className={`flex items-center gap-3 p-3 rounded-lg border transition-all duration-300 ${
                              item.packed ? 'bg-muted border-accent' : 'bg-card'
                            }`}
                          >
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => togglePackingItem(item.id)}
                              className="p-1"
                            >
                              {item.packed ? (
                                <CheckCircle2 className="w-5 h-5 text-accent" />
                              ) : (
                                <div className="w-5 h-5 border-2 border-muted-foreground rounded-full" />
                              )}
                            </Button>
                            <div className="flex-1">
                              <span className={`text-sm font-medium ${item.packed ? 'line-through text-muted-foreground' : ''}`}>
                                {item.name}
                              </span>
                              {item.essential && (
                                <Badge variant="destructive" className="ml-2 text-xs">
                                  Thiết yếu
                                </Badge>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="suggestions" className="space-y-6">
          <Card className="shadow-card-custom">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lightbulb className="w-5 h-5" />
                Gợi ý chuyến đi
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-6">
                Khám phá những điểm đến tuyệt vời với lịch trình được gợi ý chi tiết
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {travelSuggestions.map((suggestion) => (
                  <Card key={suggestion.id} className="shadow-sm border hover:shadow-md transition-shadow">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle className="text-lg mb-2">{suggestion.title}</CardTitle>
                          <p className="text-sm text-muted-foreground">{suggestion.description}</p>
                        </div>
                        <Heart className="w-5 h-5 text-muted-foreground cursor-pointer hover:text-red-500" />
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-muted-foreground" />
                          <span>{suggestion.duration}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Wallet className="w-4 h-4 text-muted-foreground" />
                          <span className="text-xs">{suggestion.budget}</span>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2 text-sm">
                        <Badge variant="outline" className="text-xs">
                          {suggestion.season}
                        </Badge>
                      </div>
                      
                      <div>
                        <h4 className="text-sm font-medium mb-2">Điểm nổi bật:</h4>
                        <div className="grid grid-cols-2 gap-1">
                          {suggestion.highlights.map((highlight, index) => (
                            <div key={index} className="flex items-center gap-2 text-xs text-muted-foreground">
                              <Star className="w-3 h-3" />
                              {highlight}
                            </div>
                          ))}
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="text-sm font-medium mb-2">Lời khuyên:</h4>
                        <ul className="space-y-1">
                          {suggestion.tips.slice(0, 2).map((tip, index) => (
                            <li key={index} className="text-xs text-muted-foreground flex items-start gap-2">
                              <span className="text-accent">•</span>
                              {tip}
                            </li>
                          ))}
                        </ul>
                      </div>
                      
                      <div className="flex gap-2 pt-2">
                        <Button size="sm" variant="outline" className="flex-1">
                          Xem chi tiết
                        </Button>
                        <Button size="sm" className="flex-1">
                          Sử dụng gợi ý
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
              
              <div className="mt-8 text-center">
                <Card className="bg-gradient-to-r from-primary/10 to-accent/10 border-dashed">
                  <CardContent className="py-8">
                    <Lightbulb className="w-12 h-12 mx-auto mb-4 text-primary" />
                    <h3 className="text-lg font-semibold mb-2">Cần gợi ý cá nhân hóa?</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Chia sẻ sở thích và ngân sách của bạn để nhận được những gợi ý phù hợp nhất
                    </p>
                    <Button variant="outline" size="sm">
                      Tạo gợi ý riêng
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="budget" className="space-y-6">
          <Card className="shadow-card-custom">
            <CardHeader>
              <CardTitle>Kế hoạch ngân sách</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-16">
                <AlertCircle className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-xl font-semibold mb-2">Đang phát triển</h3>
                <p className="text-muted-foreground">
                  Tính năng quản lý ngân sách chi tiết sẽ có trong phiên bản tiếp theo
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};