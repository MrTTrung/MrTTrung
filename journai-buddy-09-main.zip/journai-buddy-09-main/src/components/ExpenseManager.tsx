import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon, Plus, Edit, Trash2, TrendingUp, Wallet } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { getExpensesByTripId, formatCurrency, Expense } from "@/data/mockData";
import { useToast } from "@/hooks/use-toast";

interface ExpenseManagerProps {
  tripId: string;
}

const categories = [
  { value: "Ăn uống", label: "Ăn uống", icon: "🍽️" },
  { value: "Di chuyển", label: "Di chuyển", icon: "🚗" },
  { value: "Lưu trú", label: "Lưu trú", icon: "🏨" },
  { value: "Vui chơi", label: "Vui chơi", icon: "🎉" },
  { value: "Mua sắm", label: "Mua sắm", icon: "🛍️" },
  { value: "Khác", label: "Khác", icon: "💰" }
];

export const ExpenseManager = ({ tripId }: ExpenseManagerProps) => {
  const [expenses, setExpenses] = useState<Expense[]>(getExpensesByTripId(tripId));
  const [showForm, setShowForm] = useState(false);
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [formData, setFormData] = useState({
    date: new Date(),
    category: "",
    amount: "",
    description: "",
    currency: "VND"
  });
  const { toast } = useToast();

  const resetForm = () => {
    setFormData({
      date: new Date(),
      category: "",
      amount: "",
      description: "",
      currency: "VND"
    });
    setShowForm(false);
    setEditingExpense(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.category || !formData.amount || !formData.description) {
      toast({
        title: "Lỗi",
        description: "Vui lòng điền đầy đủ thông tin",
        variant: "destructive"
      });
      return;
    }

    const newExpense: Expense = {
      id: editingExpense?.id || Date.now().toString(),
      tripId,
      date: formData.date.toISOString().split('T')[0],
      category: formData.category,
      amount: parseFloat(formData.amount),
      description: formData.description,
      currency: formData.currency
    };

    if (editingExpense) {
      setExpenses(expenses.map(expense => expense.id === editingExpense.id ? newExpense : expense));
      toast({
        title: "Đã cập nhật",
        description: "Chi phí đã được cập nhật thành công"
      });
    } else {
      setExpenses([...expenses, newExpense]);
      toast({
        title: "Đã thêm",
        description: "Chi phí mới đã được thêm thành công"
      });
    }

    resetForm();
  };

  const handleEdit = (expense: Expense) => {
    setEditingExpense(expense);
    setFormData({
      date: new Date(expense.date),
      category: expense.category,
      amount: expense.amount.toString(),
      description: expense.description,
      currency: expense.currency
    });
    setShowForm(true);
  };

  const handleDelete = (expenseId: string) => {
    if (window.confirm("Bạn có chắc chắn muốn xóa chi phí này?")) {
      setExpenses(expenses.filter(expense => expense.id !== expenseId));
      toast({
        title: "Đã xóa",
        description: "Chi phí đã được xóa thành công"
      });
    }
  };

  const totalExpense = expenses.reduce((sum, expense) => sum + expense.amount, 0);
  
  const expensesByCategory = categories.map(cat => ({
    ...cat,
    total: expenses
      .filter(expense => expense.category === cat.value)
      .reduce((sum, expense) => sum + expense.amount, 0),
    count: expenses.filter(expense => expense.category === cat.value).length
  })).filter(cat => cat.count > 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Quản lý chi phí</h2>
        <Button onClick={() => setShowForm(true)} variant="travel">
          <Plus className="w-4 h-4 mr-2" />
          Thêm chi phí
        </Button>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Tổng chi phí</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <Wallet className="w-6 h-6 text-primary" />
              <span className="text-2xl font-bold">{formatCurrency(totalExpense)}</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Số giao dịch</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <TrendingUp className="w-6 h-6 text-secondary" />
              <span className="text-2xl font-bold">{expenses.length}</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Chi phí trung bình/ngày</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <CalendarIcon className="w-6 h-6 text-accent" />
              <span className="text-2xl font-bold">
                {expenses.length > 0 ? formatCurrency(totalExpense / expenses.length) : formatCurrency(0)}
              </span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Category Breakdown */}
      {expensesByCategory.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Chi phí theo danh mục</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {expensesByCategory.map((category) => (
                <div key={category.value} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <span className="text-xl">{category.icon}</span>
                    <div>
                      <span className="font-medium">{category.label}</span>
                      <span className="text-sm text-muted-foreground ml-2">({category.count} giao dịch)</span>
                    </div>
                  </div>
                  <span className="font-semibold">{formatCurrency(category.total)}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {showForm && (
        <Card className="shadow-card-custom">
          <CardHeader>
            <CardTitle>
              {editingExpense ? "Chỉnh sửa chi phí" : "Thêm chi phí mới"}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Ngày</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left font-normal",
                          !formData.date && "text-muted-foreground"
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {format(formData.date, "dd/MM/yyyy")}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={formData.date}
                        onSelect={(date) => date && setFormData({ ...formData, date })}
                        initialFocus
                        className="pointer-events-auto"
                      />
                    </PopoverContent>
                  </Popover>
                </div>

                <div className="space-y-2">
                  <Label>Danh mục</Label>
                  <Select value={formData.category} onValueChange={(value) => setFormData({ ...formData, category: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Chọn danh mục" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((category) => (
                        <SelectItem key={category.value} value={category.value}>
                          <div className="flex items-center gap-2">
                            <span>{category.icon}</span>
                            <span>{category.label}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="amount">Số tiền</Label>
                  <Input
                    id="amount"
                    type="number"
                    placeholder="0"
                    value={formData.amount}
                    onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label>Đơn vị tiền tệ</Label>
                  <Select value={formData.currency} onValueChange={(value) => setFormData({ ...formData, currency: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="VND">VND</SelectItem>
                      <SelectItem value="USD">USD</SelectItem>
                      <SelectItem value="EUR">EUR</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Mô tả</Label>
                <Input
                  id="description"
                  placeholder="VD: Bữa trưa tại nhà hàng ABC"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  required
                />
              </div>

              <div className="flex gap-4">
                <Button type="button" variant="outline" onClick={resetForm} className="flex-1">
                  Hủy
                </Button>
                <Button type="submit" variant="travel" className="flex-1">
                  {editingExpense ? "Cập nhật" : "Thêm chi phí"}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Expense List */}
      <div className="space-y-4">
        {expenses.length === 0 ? (
          <Card>
            <CardContent className="text-center py-12">
              <p className="text-muted-foreground mb-4">Chưa có chi phí nào được ghi nhận</p>
              <Button onClick={() => setShowForm(true)} variant="travel">
                <Plus className="w-4 h-4 mr-2" />
                Thêm chi phí đầu tiên
              </Button>
            </CardContent>
          </Card>
        ) : (
          expenses.map((expense) => {
            const category = categories.find(cat => cat.value === expense.category);
            return (
              <Card key={expense.id} className="shadow-card-custom hover:shadow-travel transition-shadow duration-300">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{category?.icon || "💰"}</span>
                      <div>
                        <h3 className="font-semibold">{expense.description}</h3>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <span>{expense.category}</span>
                          <span>{new Date(expense.date).toLocaleDateString('vi-VN')}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-lg font-bold">{formatCurrency(expense.amount, expense.currency)}</span>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" onClick={() => handleEdit(expense)}>
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="destructive" onClick={() => handleDelete(expense.id)}>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })
        )}
      </div>
    </div>
  );
};