import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/useAuth';

export interface Trip {
  id: string;
  title: string;
  location: string;
  start_date: string;
  end_date: string;
  notes: string;
  tags: string[];
  cover_image?: string;
  user_id: string;
  created_at: string;
  updated_at: string;
  // Legacy compatibility - required for compatibility with existing components
  startDate: string;
  endDate: string;
  rating: number;
  coverImage?: string;
}

export const useSupabaseTrips = () => {
  const [trips, setTrips] = useState<Trip[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  const { user } = useAuth();

  const fetchTrips = async () => {
    try {
      const { data, error } = await supabase
        .from('trips')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      
      // Add legacy compatibility fields
      const tripsWithCompatibility = (data || []).map(trip => ({
        ...trip,
        notes: trip.notes || '',
        tags: trip.tags || [],
        startDate: trip.start_date,
        endDate: trip.end_date,
        rating: 5, // Default rating for compatibility
        coverImage: trip.cover_image
      }));
      
      setTrips(tripsWithCompatibility);
    } catch (error) {
      console.error('Error fetching trips:', error);
      toast({
        title: 'Lỗi',
        description: 'Không thể tải danh sách chuyến đi',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const createTrip = async (tripData: Omit<Trip, 'id' | 'user_id' | 'created_at' | 'updated_at'>) => {
    if (!user) {
      toast({
        title: 'Lỗi',
        description: 'Bạn cần đăng nhập để tạo chuyến đi',
        variant: 'destructive'
      });
      return null;
    }

    try {
      const { data, error } = await supabase
        .from('trips')
        .insert({
          ...tripData,
          user_id: user.id
        })
        .select()
        .single();

      if (error) throw error;

      toast({
        title: 'Thành công',
        description: 'Chuyến đi mới đã được tạo!'
      });

      fetchTrips(); // Refresh the list
      return data;
    } catch (error) {
      console.error('Error creating trip:', error);
      toast({
        title: 'Lỗi',
        description: 'Không thể tạo chuyến đi mới',
        variant: 'destructive'
      });
      return null;
    }
  };

  const updateTrip = async (id: string, updates: Partial<Trip>) => {
    try {
      const { data, error } = await supabase
        .from('trips')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;

      toast({
        title: 'Thành công',
        description: 'Chuyến đi đã được cập nhật!'
      });

      fetchTrips(); // Refresh the list
      return data;
    } catch (error) {
      console.error('Error updating trip:', error);
      toast({
        title: 'Lỗi',
        description: 'Không thể cập nhật chuyến đi',
        variant: 'destructive'
      });
      return null;
    }
  };

  const deleteTrip = async (id: string) => {
    try {
      const { error } = await supabase
        .from('trips')
        .delete()
        .eq('id', id);

      if (error) throw error;

      toast({
        title: 'Thành công',
        description: 'Chuyến đi đã được xóa!'
      });

      fetchTrips(); // Refresh the list
      return true;
    } catch (error) {
      console.error('Error deleting trip:', error);
      toast({
        title: 'Lỗi',
        description: 'Không thể xóa chuyến đi',
        variant: 'destructive'
      });
      return false;
    }
  };

  useEffect(() => {
    if (user) {
      fetchTrips();
    } else {
      setTrips([]);
      setLoading(false);
    }
  }, [user]);

  return {
    trips,
    loading,
    createTrip,
    updateTrip,
    deleteTrip,
    refetchTrips: fetchTrips
  };
};